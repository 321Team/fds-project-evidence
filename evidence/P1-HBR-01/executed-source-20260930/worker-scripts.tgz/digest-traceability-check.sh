#!/usr/bin/env bash
set -euo pipefail
set +x

HARBOR_REGISTRY="10.1.93.54"

NAMESPACE="${1:?namespace를 지정하세요}"
POD_NAME="${2:?pod name을 지정하세요}"
CONTAINER_NAME="${3:?대상 container name을 명시하세요}"
HARBOR_IMAGE_REF="${4:?immutable Harbor image reference required}"
POD_CONTAINER_NAME="$CONTAINER_NAME"
POD_IMAGE="$HARBOR_IMAGE_REF"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/pod-review-binding.sh"
require_pod_review_inputs || exit 1
: "${POD_UID:?create-response Pod UID required}"
: "${REVIEW_RUN_ID:?review run required}"
: "${RUN_NONCE:?invocation nonce required}"
CA_FILE="${CA_FILE:?CA_FILE 환경변수를 지정하세요}"

if [ -z "${WORKER_ROBOT_USER:-}" ] || [ -z "${WORKER_ROBOT_SECRET:-}" ]; then
  echo "ERROR: WORKER_ROBOT_USER 또는 WORKER_ROBOT_SECRET 환경변수가 주입되지 않았습니다."
  exit 1
fi

if [[ "${WORKER_ROBOT_USER}" == *$'\n'* || "${WORKER_ROBOT_USER}" == *$'\r'* ]] || \
   [[ "${WORKER_ROBOT_SECRET}" == *$'\n'* || "${WORKER_ROBOT_SECRET}" == *$'\r'* ]]; then
  echo "ERROR: 개행 문자 포함"
  exit 1
fi

if [ ! -f "${CA_FILE}" ]; then
  echo "ERROR: CA_FILE(${CA_FILE})이 존재하지 않습니다."
  exit 1
fi

HARBOR_HOST="${HARBOR_IMAGE_REF%%/*}"
HARBOR_REPO_DIGEST="${HARBOR_IMAGE_REF#*/}"
HARBOR_DIGEST_REF="${HARBOR_REPO_DIGEST##*@}"
HARBOR_REPO="${HARBOR_REPO_DIGEST%@*}"
if [[ ! "$HARBOR_REPO" =~ ^[a-z0-9]+([._-][a-z0-9]+)*(/[a-z0-9]+([._-][a-z0-9]+)*)*$ ]] ||
   [ "$HARBOR_DIGEST_REF" != "$EXPECTED_HARBOR_DIGEST" ]; then
  echo "ERROR: expected an approved immutable registry/repository@sha256 reference" >&2
  exit 1
fi

if [ "${HARBOR_HOST}" != "${HARBOR_REGISTRY}" ]; then
  echo "ERROR: harbor-image-ref의 registry host가 다릅니다: ${HARBOR_HOST}"
  exit 1
fi

umask 077
CURL_CONFIG_FILE="$(mktemp)"
cleanup_curl_config() {
  local rc=$?
  trap - EXIT INT TERM
  if [ -n "$CURL_CONFIG_FILE" ] && ! rm -f -- "$CURL_CONFIG_FILE"; then
    echo "ERROR: curl credential config cleanup failed" >&2
    [ "$rc" -ne 0 ] || rc=1
  fi
  exit "$rc"
}
trap cleanup_curl_config EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
chmod 600 "${CURL_CONFIG_FILE}"

_curl_cfg_escape() {
  printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'
}
printf 'user = "%s:%s"\n' \
  "$(_curl_cfg_escape "${WORKER_ROBOT_USER}")" \
  "$(_curl_cfg_escape "${WORKER_ROBOT_SECRET}")" \
  > "${CURL_CONFIG_FILE}"

MANIFEST_HEADERS=$(curl -q -K "${CURL_CONFIG_FILE}" \
  --fail --silent --show-error --cacert "${CA_FILE}" \
  --proto "=https" --connect-timeout 10 --max-time 30 \
  -o /dev/null -D - \
  -H "Accept: application/vnd.oci.image.manifest.v1+json,application/vnd.docker.distribution.manifest.v2+json" \
  "https://${HARBOR_HOST}/v2/${HARBOR_REPO}/manifests/${HARBOR_DIGEST_REF}")

HARBOR_DIGEST=$(printf '%s' "${MANIFEST_HEADERS}" | tr -d '\r' \
  | awk -F': ' 'tolower($1)=="docker-content-digest"{print $2; exit}')

if [[ ! "${HARBOR_DIGEST}" =~ ^sha256:[0-9a-f]{64}$ ]]; then
  echo "ERROR: Harbor manifest 조회에서 유효한 Docker-Content-Digest를 얻지 못함"
  exit 1
fi
echo "OK: Harbor manifest Digest: ${HARBOR_DIGEST}"

MANIFEST_TYPE=$(printf '%s' "$MANIFEST_HEADERS" | tr -d '\r' | awk -F': ' 'tolower($1)=="content-type"{print $2; exit}')
case "${MANIFEST_TYPE%%;*}" in
  application/vnd.oci.image.manifest.v1+json|application/vnd.docker.distribution.manifest.v2+json) ;;
  *) echo "ERROR: manifest type is not a verified single-platform manifest" >&2; exit 1 ;;
esac
[ "$HARBOR_DIGEST" = "$EXPECTED_HARBOR_DIGEST" ] || { echo 'ERROR: Harbor digest differs from approved digest' >&2; exit 1; }
POD_SNAPSHOT=$("${KUBECTL[@]}" get pod "$POD_NAME" -n "$NAMESPACE" -o json)
if ! POD_IMAGE_ID=$(printf '%s' "$POD_SNAPSHOT" | bound_pod_image_id); then
  echo 'ERROR: Pod UID/run/node/container/credential binding or Ready state mismatch' >&2
  exit 1
fi
POD_DIGEST="${POD_IMAGE_ID##*@}"
[[ "$POD_DIGEST" =~ ^sha256:[0-9a-f]{64}$ ]] || { echo 'ERROR: invalid Pod imageID digest' >&2; exit 1; }
[ "$POD_DIGEST" = "$HARBOR_DIGEST" ] || { echo 'ERROR: Pod/Harbor manifest digest mismatch' >&2; exit 1; }
rm -f -- "$CURL_CONFIG_FILE"
CURL_CONFIG_FILE=""
echo "PASS: Pod/Harbor manifest digest binding uid=$POD_UID node=$NODE_NAME container=$POD_CONTAINER_NAME digest=$POD_DIGEST"
