#!/usr/bin/env bash
set -euo pipefail
set +x

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/lib/load-review-run-env.sh"

HARBOR_REGISTRY="10.1.93.54"
source "${SCRIPT_DIR}/lib/pod-review-binding.sh"
source "${SCRIPT_DIR}/lib/pod-review-lifecycle.sh"
require_pod_review_inputs || { echo "ERROR: invalid review inputs" >&2; exit 1; }
POD_OVERRIDES_FILE="${POD_OVERRIDES_FILE:-./pod-restricted-psa-overrides.json}"

if [ -z "${WORKER_ROBOT_SECRET:-}" ] || [ -z "${WORKER_ROBOT_USER:-}" ]; then
  echo "ERROR: WORKER_ROBOT_USER 또는 WORKER_ROBOT_SECRET 환경변수가 주입되지 않았습니다."
  exit 1
fi

load_review_run_env "./review-run.env" "./review-run.env.sha256" || exit 1

TEST_IMAGE="${HARBOR_REGISTRY}/fds/test:${TEST_TAG}"
POD_IMAGE="${HARBOR_REGISTRY}/fds/test@${EXPECTED_HARBOR_DIGEST}"
RUN_NONCE="$(od -An -N16 -tx1 /dev/urandom | tr -d ' \n')"
[[ "$RUN_NONCE" =~ ^[0-9a-f]{32}$ ]] || exit 1
POD_NAME="p1-hbr-${RUN_NONCE}"
CLEANUP_TIMEOUT_SECONDS="${CLEANUP_TIMEOUT_SECONDS:-60}"
[[ "$CLEANUP_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]] || exit 1
: "${CA_FILE:?Harbor CA file required}"
[ -f "$CA_FILE" ] || exit 1
[[ "$WORKER_ROBOT_USER" != *:* && "$WORKER_ROBOT_USER" != *$'\n'* && "$WORKER_ROBOT_USER" != *$'\r'* ]] || exit 1
[[ "$WORKER_ROBOT_SECRET" != *$'\n'* && "$WORKER_ROBOT_SECRET" != *$'\r'* ]] || exit 1
export WORKER_ROBOT_USER WORKER_ROBOT_SECRET
preflight_pod_review || exit 1
[ -f "$POD_OVERRIDES_FILE" ] || exit 1
jq -e '(.spec.containers | length) == 1' "$POD_OVERRIDES_FILE" >/dev/null || exit 1
POD_CONTAINER_NAME=$(jq -er '.spec.containers[0].name | select(type == "string" and length > 0)' "$POD_OVERRIDES_FILE")
POD_MANIFEST=$(jq --arg name "$POD_NAME" --arg ns "$NAMESPACE" --arg run "$REVIEW_RUN_ID" \
  --arg nonce "$RUN_NONCE" --arg img "$POD_IMAGE" --arg node "$NODE_NAME" \
  --arg sa "$SERVICE_ACCOUNT_NAME" --arg secret "$PULL_SECRET_NAME" '
  .apiVersion = "v1" | .kind = "Pod"
  | .metadata = {name:$name, namespace:$ns, labels:{"review-run-id":$run,"review-invocation":$nonce}}
  | .spec.containers[0].image = $img | .spec.containers[0].imagePullPolicy = "Always"
  | .spec.nodeName = $node | .spec.serviceAccountName = $sa
  | .spec.automountServiceAccountToken = false | .spec.imagePullSecrets = [{name:$secret}]
  | .spec.restartPolicy = "Never"' "$POD_OVERRIDES_FILE")
TEST_AUTH_DIR="" POD_UID="" CREATE_ATTEMPTED=0 LOGIN_ATTEMPTED=0 REVIEW_CHECKS_PASSED=0
trap 'cleanup_review 130' INT
trap 'cleanup_review 143' TERM
trap cleanup_review EXIT
TEST_AUTH_DIR="$(sudo mktemp -d)"
sudo chmod 0700 "$TEST_AUTH_DIR"

export CRICTL_AUTH
CRICTL_AUTH=$(printf '%s:%s' "${WORKER_ROBOT_USER}" "${WORKER_ROBOT_SECRET}" | base64)
PULL_EXIT_CODE=0
sudo -E crictl pull "${TEST_IMAGE}" || PULL_EXIT_CODE=$?
unset CRICTL_AUTH

if [ ${PULL_EXIT_CODE} -ne 0 ]; then
  echo "FAIL: crictl pull 실패 (Exit Code: ${PULL_EXIT_CODE})"
  exit 1
fi

LOGIN_ATTEMPTED=1
LOGIN_OUTPUT=""
LOGIN_EXIT_CODE=0
LOGIN_OUTPUT=$(printf '%s' "${WORKER_ROBOT_SECRET}" | \
  sudo env DOCKER_CONFIG="${TEST_AUTH_DIR}" nerdctl -n k8s.io login "${HARBOR_REGISTRY}" \
    --username "${WORKER_ROBOT_USER}" \
    --password-stdin 2>&1) || LOGIN_EXIT_CODE=$?

if [ ${LOGIN_EXIT_CODE} -ne 0 ]; then
  echo "ERROR: 로그인 자체가 실패해 Push DENY 시험이 무효함 (Credential/네트워크를 먼저 확인)"
  echo "Login Output: ${LOGIN_OUTPUT}"
  exit 1
fi

DENY_TEST_TAG="worker-push-denytest-${REVIEW_RUN_ID}"
DENY_TEST_IMAGE="${HARBOR_REGISTRY}/fds/test:${DENY_TEST_TAG}"
sudo env DOCKER_CONFIG="${TEST_AUTH_DIR}" nerdctl -n k8s.io tag "${TEST_IMAGE}" "${DENY_TEST_IMAGE}"
PUSH_OUTPUT=""
PUSH_EXIT_CODE=0
PUSH_OUTPUT=$(sudo env DOCKER_CONFIG="${TEST_AUTH_DIR}" nerdctl -n k8s.io \
  --hosts-dir /etc/containerd/certs.d push "${DENY_TEST_IMAGE}" 2>&1) || PUSH_EXIT_CODE=$?

AMBIGUOUS_PUSH_MARKERS='unauthorized: authentication required|timeout|TLS|certificate|connection refused|EOF|temporary failure|dial tcp'
if [ ${LOGIN_EXIT_CODE} -eq 0 ] && [ ${PUSH_EXIT_CODE} -ne 0 ] && \
   echo "${PUSH_OUTPUT}" | grep -iqE "${AMBIGUOUS_PUSH_MARKERS}"; then
  echo "ERROR: push 출력에 인증/전송 오류로 해석될 수 있는 신호가 포함됨 — denied 문구와 섞여 있어도 권한 거부로 확정할 수 없어 시험 무효"
  echo "Push Output: ${PUSH_OUTPUT}"
  exit 1
elif [ ${LOGIN_EXIT_CODE} -eq 0 ] && [ ${PUSH_EXIT_CODE} -ne 0 ] && \
     echo "${PUSH_OUTPUT}" | grep -iqE "denied: requested access|unauthorized to access repository.*action: push"; then
  echo "PASS: 로그인 성공 후 Push DENY(권한 거부) 확인 완료"
else
  echo "FAIL: 로그인 실패, 또는 Push 차단/성공 원인이 검증된 권한 거부가 아님"
  echo "Push Output: ${PUSH_OUTPUT}"
  exit 1
fi

CREATE_ATTEMPTED=1
CREATE_RESPONSE=""
if ! CREATE_RESPONSE=$(printf '%s' "$POD_MANIFEST" | "${KUBECTL[@]}" create -f - -o json); then
  echo "ERROR: create failed/response lost; cleanup will attempt invocation-bound recovery" >&2
  exit 1
fi
if ! POD_UID=$(printf '%s' "$CREATE_RESPONSE" | owned_pod_uid); then
  echo "ERROR: invalid create response; cleanup will attempt invocation-bound recovery" >&2
  exit 1
fi
echo "CREATED: context=$KUBE_CONTEXT namespace=$NAMESPACE pod=$POD_NAME uid=$POD_UID run=$REVIEW_RUN_ID invocation=$RUN_NONCE node=$NODE_NAME"
"${KUBECTL[@]}" wait --for=condition=Ready "pod/$POD_NAME" -n "$NAMESPACE" --timeout=60s
export KUBE_CONTEXT NAMESPACE NODE_NAME SERVICE_ACCOUNT_NAME PULL_SECRET_NAME EXPECTED_HARBOR_DIGEST
export POD_UID REVIEW_RUN_ID RUN_NONCE CA_FILE
bash "${SCRIPT_DIR}/digest-traceability-check.sh" "$NAMESPACE" "$POD_NAME" "$POD_CONTAINER_NAME" "$POD_IMAGE"
REVIEW_CHECKS_PASSED=1
