#!/usr/bin/env bash
load_review_run_env() {
  local env_file="$1"
  local sha_file="$2"

  if [ ! -f "${env_file}" ] || [ ! -f "${sha_file}" ]; then
    echo "ERROR: ${env_file} 또는 ${sha_file} 파일이 없습니다. Runner에서 전달받았는지 확인하세요." >&2
    return 1
  fi

  local base_name
  base_name="$(basename -- "${env_file}")"
  local escaped_name="${base_name//./\\.}"
  local line_pattern="^[0-9a-fA-F]{64}[[:space:]][ *](\\./)?${escaped_name}\$"

  local matches
  matches="$(grep -cE "${line_pattern}" "${sha_file}" || true)"
  if [ "${matches}" -ne 1 ]; then
    echo "ERROR: ${sha_file}에 ${base_name} 항목이 정확히 1개 있어야 합니다 (실제: ${matches}개)." >&2
    return 1
  fi

  local snapshot
  snapshot="$(mktemp)"
  trap 'rm -f "${snapshot}"' RETURN

  cp -- "${env_file}" "${snapshot}"

  local expected_hash actual_hash
  expected_hash="$(grep -E "${line_pattern}" "${sha_file}" | head -n1 | awk '{print tolower($1)}')"
  actual_hash="$(sha256sum "${snapshot}" | awk '{print $1}')"

  if [ "${expected_hash}" != "${actual_hash}" ]; then
    echo "ERROR: ${env_file} 무결성 검증 실패. 파일이 전송 중 변조/손상되었을 수 있습니다." >&2
    return 1
  fi

  unset TEST_TAG REVIEW_RUN_ID
  local -A seen_keys=()
  local allowed_keys="TEST_TAG REVIEW_RUN_ID"
  local env_key env_value

  while IFS='=' read -r env_key env_value; do
    [[ -z "${env_key}" || "${env_key}" =~ ^[[:space:]]*# ]] && continue
    case " ${allowed_keys} " in
      *" ${env_key} "*)
        if [ -n "${seen_keys[${env_key}]:-}" ]; then
          echo "ERROR: ${env_file}에 ${env_key} 키가 중복됨 (마지막 값을 조용히 채택하지 않음)" >&2
          return 1
        fi
        seen_keys[${env_key}]=1

        case "${env_key}" in
          TEST_TAG)
            if [[ ! "${env_value}" =~ ^[A-Za-z0-9_][A-Za-z0-9._-]{0,127}$ ]]; then
              echo "ERROR: TEST_TAG 형식이 Docker tag 규칙에 맞지 않음: '${env_value}'" >&2
              return 1
            fi
            ;;
          REVIEW_RUN_ID)
            if [[ ! "${env_value}" =~ ^[a-z0-9]([a-z0-9-]{0,47}[a-z0-9])?$ ]]; then
              echo "ERROR: REVIEW_RUN_ID 형식이 k8s 리소스 이름 규칙(소문자/숫자/-)에 맞지 않음: '${env_value}'" >&2
              return 1
            fi
            ;;
        esac

        printf -v "${env_key}" '%s' "${env_value}"
        ;;
      *)
        echo "ERROR: ${env_file}에 허용되지 않은 키(${env_key})가 존재함" >&2
        return 1
        ;;
    esac
  done < "${snapshot}"

  if [ -z "${TEST_TAG:-}" ] || [ -z "${REVIEW_RUN_ID:-}" ]; then
    echo "ERROR: TEST_TAG 또는 REVIEW_RUN_ID가 ${env_file}에 비어 있습니다." >&2
    return 1
  fi

  echo "OK: ${env_file} 무결성 확인 및 안전 로드 완료 (Run ID: ${REVIEW_RUN_ID})" >&2
  return 0
}
