sha256sum /proc/2713/exe 
