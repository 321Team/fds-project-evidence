import os, re, sys
d, host, run, win = sys.argv[1:5]
head = re.compile(r'^(\d+\.\d+) (?:\S+ +)??(?:(?:In|Out|M|P|B) +)?IP (\d+\.\d+\.\d+\.\d+)\.(\d+) > (\d+\.\d+\.\d+\.\d+)\.(\d+): .*?seq (\d+)')
req = re.compile(r'(GET|POST) /[^ ?]*\?(?:[^ ]*&)?cutover=cutover-' + re.escape(run) + r'-([A-Za-z0-9]+)-([A-Za-z0-9]+)(?=[& ])[^ ]* (HTTP/1\.[01])')
def hdr(name, text):
    m = re.search(r'(?mi)^' + name + r': *([^\s]+)', text)
    return m.group(1) if m else '-'
out = open(os.path.join(d, 'hits.txt'), 'a')
seen = set()
blocks = hits = other = 0
def flush(cur):
    global blocks, hits, other
    if cur is None:
        return
    m, body = cur
    blocks += 1
    text = '\n'.join(body)
    r = req.search(text)
    if not r:
        other += 1                 # 표식 없는 요청: 개수만 센다(내용 저장 안 함)
        return
    t, sip, sport, dip, dport, seq = m.groups()
    key = (sip, sport, dip, dport, seq, r.group(2), r.group(3))
    if key in seen:                # 같은 패킷이 두 인터페이스에서 잡히거나 재전송된 경우 1번만 센다
        return
    seen.add(key)
    hits += 1
    out.write('HIT host=%s run=%s win=%s tag=%s id=%s t=%s src=%s:%s dst=%s:%s seq=%s method=%s proto=%s hdr_host=%s xri=%s\n' % (
        host, run, win, r.group(2), r.group(3), t, sip, sport, dip, dport, seq, r.group(1), r.group(4),
        hdr('Host', text), hdr('X-Real-IP', text)))
    out.flush()
cur = None
for line in sys.stdin:
    line = line.rstrip('\n')
    m = head.match(line)
    if m:
        flush(cur)
        cur = (m, [])
    elif cur is not None:
        cur[1].append(line)
flush(cur)
out.close()
with open(os.path.join(d, 'counts.txt'), 'w') as f:
    f.write('blocks=%d hits=%d other=%d\n' % (blocks, hits, other))
