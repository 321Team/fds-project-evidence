sha256sum -- /root/sec19-diagnostic-code.0HTUeXEm/backup-version-capture.sh 
