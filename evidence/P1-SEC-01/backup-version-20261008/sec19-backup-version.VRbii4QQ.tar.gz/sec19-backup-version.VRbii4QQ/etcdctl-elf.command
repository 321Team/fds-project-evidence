readelf -h -l /proc/2713/root/usr/local/bin/etcdctl 
