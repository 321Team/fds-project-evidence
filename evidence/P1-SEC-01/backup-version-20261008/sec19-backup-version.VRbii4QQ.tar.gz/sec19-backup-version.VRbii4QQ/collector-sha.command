sha256sum -- /root/sec19-diagnostic-code.t6CpeQMG/backup-version-capture.sh 
