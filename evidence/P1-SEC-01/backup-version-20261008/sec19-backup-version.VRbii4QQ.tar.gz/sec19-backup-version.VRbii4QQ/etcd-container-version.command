kubectl --kubeconfig=/etc/kubernetes/admin.conf --request-timeout=10s -n kube-system exec etcd-k8s-control01 -c etcd -- /usr/local/bin/etcd --version 
