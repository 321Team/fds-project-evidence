file -L /proc/2713/root/usr/local/bin/etcd 
