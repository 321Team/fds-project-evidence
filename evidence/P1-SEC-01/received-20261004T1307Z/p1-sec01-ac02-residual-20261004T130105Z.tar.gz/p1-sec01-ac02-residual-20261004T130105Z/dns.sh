H="$1"
if command -v python3 >/dev/null 2>&1; then PY=python3; elif command -v python >/dev/null 2>&1; then PY=python; else PY=""; fi
if [ -n "$PY" ]; then
  $PY -c 'import socket,sys
try:
    print("RESOLVED python " + socket.gethostbyname(sys.argv[1]))
except Exception as e:
    print("FAILED python " + type(e).__name__)' "$H"
elif command -v getent >/dev/null 2>&1; then
  if getent hosts "$H" >/dev/null 2>&1; then echo "RESOLVED getent"; else echo "FAILED getent"; fi
else
  echo "NO_TOOL"
fi
