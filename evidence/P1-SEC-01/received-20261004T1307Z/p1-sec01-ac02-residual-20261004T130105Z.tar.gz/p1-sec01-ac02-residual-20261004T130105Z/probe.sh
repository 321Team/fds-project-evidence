H="$1"; P="$2"
if command -v python3 >/dev/null 2>&1; then PY=python3; elif command -v python >/dev/null 2>&1; then PY=python; else PY=""; fi
if [ -n "$PY" ]; then
  $PY -c 'import socket,sys
s=socket.socket(); s.settimeout(3)
try:
    s.connect((sys.argv[1],int(sys.argv[2]))); print("CONNECTED python")
except socket.timeout:
    print("TIMEOUT python")
except ConnectionRefusedError:
    print("REFUSED python")
except Exception as e:
    print("ERROR python " + type(e).__name__)' "$H" "$P"
elif command -v nc >/dev/null 2>&1; then
  S=$(date +%s)
  NO=$(echo | nc -w 3 "$H" "$P" 2>&1); RC=$?
  E=$(date +%s); D=$((E-S))
  if [ "$RC" -eq 0 ]; then echo "CONNECTED nc"
  elif echo "$NO" | grep -qi "refused"; then echo "REFUSED nc"
  elif [ "$D" -ge 2 ]; then echo "TIMEOUT nc"
  else echo "ERROR nc elapsed=${D}s $(echo "$NO" | head -c 60 | tr '\n' ' ')"; fi
else
  echo "NO_TOOL"
fi
