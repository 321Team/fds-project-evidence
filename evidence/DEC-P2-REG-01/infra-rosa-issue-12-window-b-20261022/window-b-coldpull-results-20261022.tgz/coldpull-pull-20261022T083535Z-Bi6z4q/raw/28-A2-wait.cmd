python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-a2-bi6z4q pullfail 240 /home/cloudshell-user/coldpull-pull-20261022T083535Z-Bi6z4q/pod-A2-status.json 20 
