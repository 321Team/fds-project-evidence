python3 - /home/cloudshell-user/coldpull-path-after-20261022T083209Z-h0vivg/ledger.txt coldpull-path-after 
