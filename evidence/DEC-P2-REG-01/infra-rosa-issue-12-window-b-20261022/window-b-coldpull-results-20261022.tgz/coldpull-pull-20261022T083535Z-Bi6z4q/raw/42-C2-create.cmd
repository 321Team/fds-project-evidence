oc create -f /home/cloudshell-user/coldpull-pull-20261022T083535Z-Bi6z4q/pod-C2.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
