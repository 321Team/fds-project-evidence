oc delete pod fds-cp-a2-bi6z4q -n fds-app --wait=true --timeout=120s --request-timeout=20s 
