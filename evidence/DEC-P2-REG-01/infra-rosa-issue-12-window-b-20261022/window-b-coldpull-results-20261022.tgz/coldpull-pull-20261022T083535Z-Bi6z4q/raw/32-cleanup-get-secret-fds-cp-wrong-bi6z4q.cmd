oc get secret fds-cp-wrong-bi6z4q -n fds-app --request-timeout=20s -o jsonpath=\{.metadata.uid\}\{\"\ \"\}\{.metadata.labels.fds-coldpull-run\} 
