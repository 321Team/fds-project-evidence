python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-c2-bi6z4q pulled 900 /home/cloudshell-user/coldpull-pull-20261022T083535Z-Bi6z4q/pod-C2-status.json 20 
