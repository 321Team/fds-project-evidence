oc get pod fds-cp-a2-bi6z4q -n fds-app --request-timeout=20s -o name 
