oc get pod fds-cp-c2-bi6z4q -n fds-app --request-timeout=20s -o name 
