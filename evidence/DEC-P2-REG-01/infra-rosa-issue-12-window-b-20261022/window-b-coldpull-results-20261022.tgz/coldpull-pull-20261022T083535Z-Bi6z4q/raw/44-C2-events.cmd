oc get events -n fds-app --request-timeout=20s --field-selector involvedObject.uid=be66cb49-da38-46d2-9506-6a067c37369f -o json 
