oc get pod fds-cp-a1-bi6z4q -n fds-app --request-timeout=20s -o name 
