oc get events -n fds-app --request-timeout=20s --field-selector involvedObject.uid=1726b767-6ccb-4b3b-8260-cc452f6f8d63 -o json 
