bash -c set\ -euo\ pipefail\;\ cd\ \'/home/cloudshell-user/coldpull-path-after-20261022T083209Z-h0vivg\'\ \&\&\ sha256sum\ -c\ --quiet\ SHA256SUMS 
