timeout 120 oc debug node/ip-10-20-10-169.ap-northeast-2.compute.internal --to-namespace=fds-app --quiet -- chroot /host crictl images -o json 
