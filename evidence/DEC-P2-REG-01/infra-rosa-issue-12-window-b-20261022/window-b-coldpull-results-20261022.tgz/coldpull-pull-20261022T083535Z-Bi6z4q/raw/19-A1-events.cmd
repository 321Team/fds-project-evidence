oc get events -n fds-app --request-timeout=20s --field-selector involvedObject.uid=9aeb1435-fd38-4d37-8499-b8f66e97db3e -o json 
