python3 /home/cloudshell-user/wb/kit/coldpull_tool.py sa-secrets /home/cloudshell-user/coldpull-precheck-20261022T064121Z-YstgFr/sa-default.json p2-coldpull-harbor-pull 
