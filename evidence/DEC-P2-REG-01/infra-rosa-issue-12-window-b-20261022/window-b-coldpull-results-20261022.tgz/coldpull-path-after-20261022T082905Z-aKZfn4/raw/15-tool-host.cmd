oc get pod fds-cp-tool-akzfn4 -n fds-app --request-timeout=20s -o jsonpath=\{.spec.nodeName\}\{\"\ \"\}\{.status.hostIP\} 
