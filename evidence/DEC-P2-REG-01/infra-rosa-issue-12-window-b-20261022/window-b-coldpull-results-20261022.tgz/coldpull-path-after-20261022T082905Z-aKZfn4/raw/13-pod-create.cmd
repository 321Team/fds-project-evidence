oc create -f /home/cloudshell-user/coldpull-path-after-20261022T082905Z-aKZfn4/pod-tool.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
