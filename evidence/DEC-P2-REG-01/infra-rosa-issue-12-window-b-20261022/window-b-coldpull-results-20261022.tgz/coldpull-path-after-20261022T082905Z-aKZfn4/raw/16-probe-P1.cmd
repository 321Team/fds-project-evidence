timeout 40 oc exec -n fds-app fds-cp-tool-akzfn4 -- bash -c $'{ curl -sS -m 10 --cacert /ca/root.pem -o /dev/null -w \'%{http_code}\' https://10.1.93.54/v2/\n}; r=$?; echo; echo PROBE_RC=$r' 
