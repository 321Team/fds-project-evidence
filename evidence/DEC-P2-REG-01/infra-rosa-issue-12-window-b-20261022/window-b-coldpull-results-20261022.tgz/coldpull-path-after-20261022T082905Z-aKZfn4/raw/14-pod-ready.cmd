python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-tool-akzfn4 ready 300 /home/cloudshell-user/coldpull-path-after-20261022T082905Z-aKZfn4/pod-tool-status.json 20 
