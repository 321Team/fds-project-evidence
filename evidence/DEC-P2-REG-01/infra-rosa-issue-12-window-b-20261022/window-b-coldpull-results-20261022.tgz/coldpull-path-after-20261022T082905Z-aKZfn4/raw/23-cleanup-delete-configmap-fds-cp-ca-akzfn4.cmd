oc delete configmap fds-cp-ca-akzfn4 -n fds-app --wait=true --timeout=120s --request-timeout=20s 
