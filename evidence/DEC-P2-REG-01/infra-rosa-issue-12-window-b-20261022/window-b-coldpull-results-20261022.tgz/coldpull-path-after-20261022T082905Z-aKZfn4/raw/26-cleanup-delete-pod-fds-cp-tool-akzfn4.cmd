oc delete pod fds-cp-tool-akzfn4 -n fds-app --wait=true --timeout=120s --request-timeout=20s 
