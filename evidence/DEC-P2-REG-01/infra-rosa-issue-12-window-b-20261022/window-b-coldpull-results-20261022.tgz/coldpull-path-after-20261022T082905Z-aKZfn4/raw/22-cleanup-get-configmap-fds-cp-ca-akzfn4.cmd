oc get configmap fds-cp-ca-akzfn4 -n fds-app --request-timeout=20s -o jsonpath=\{.metadata.uid\}\{\"\ \"\}\{.metadata.labels.fds-coldpull-run\} 
