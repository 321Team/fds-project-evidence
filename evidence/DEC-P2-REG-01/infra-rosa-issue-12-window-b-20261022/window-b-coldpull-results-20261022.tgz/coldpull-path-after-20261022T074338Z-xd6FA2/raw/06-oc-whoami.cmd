oc whoami --request-timeout=20s 
