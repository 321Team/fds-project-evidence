oc delete configmap fds-cp-ca-xd6fa2 -n fds-app --wait=true --timeout=120s --request-timeout=20s 
