oc get configmap fds-cp-ca-xd6fa2 -n fds-app --request-timeout=20s -o name 
