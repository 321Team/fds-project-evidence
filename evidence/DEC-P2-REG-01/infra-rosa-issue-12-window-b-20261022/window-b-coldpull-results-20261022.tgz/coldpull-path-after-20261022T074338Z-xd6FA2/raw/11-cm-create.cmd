oc create -f /home/cloudshell-user/coldpull-path-after-20261022T074338Z-xd6FA2/cm.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
