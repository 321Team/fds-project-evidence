python3 /home/cloudshell-user/wb/kit/coldpull_tool.py validate 
