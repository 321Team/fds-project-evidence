oc get pod fds-cp-tool-xd6fa2 -n fds-app --request-timeout=20s -o name 
