oc get namespace fds-app --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
