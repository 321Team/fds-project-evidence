python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-tool-xd6fa2 ready 300 /home/cloudshell-user/coldpull-path-after-20261022T074338Z-xd6FA2/pod-tool-status.json 20 
