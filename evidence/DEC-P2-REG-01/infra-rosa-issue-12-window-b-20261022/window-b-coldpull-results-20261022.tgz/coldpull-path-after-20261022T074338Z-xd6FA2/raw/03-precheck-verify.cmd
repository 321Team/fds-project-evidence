bash -c set\ -euo\ pipefail\;\ cd\ \'/home/cloudshell-user/coldpull-precheck-20261022T063922Z-TMZuOc\'\ \&\&\ sha256sum\ -c\ --quiet\ SHA256SUMS 
