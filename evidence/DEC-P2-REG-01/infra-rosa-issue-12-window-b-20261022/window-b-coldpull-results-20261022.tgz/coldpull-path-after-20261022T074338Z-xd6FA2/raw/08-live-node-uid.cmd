oc get node ip-10-20-10-169.ap-northeast-2.compute.internal --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
