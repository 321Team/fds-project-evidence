python3 - /home/cloudshell-user/coldpull-precheck-20261022T063922Z-TMZuOc/ledger.txt coldpull-precheck 
