bash -c set\ -euo\ pipefail\;\ cd\ \'/home/cloudshell-user/wb/kit\'\ \&\&\ sha256sum\ -c\ SHA256SUMS 
