rosa describe cluster -c fds-rosa-hcp -o json 
