rosa version 
