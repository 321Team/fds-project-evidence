oc version --client 
