rosa whoami 
