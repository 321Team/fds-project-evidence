oc get nodes --request-timeout=20s -o json 
