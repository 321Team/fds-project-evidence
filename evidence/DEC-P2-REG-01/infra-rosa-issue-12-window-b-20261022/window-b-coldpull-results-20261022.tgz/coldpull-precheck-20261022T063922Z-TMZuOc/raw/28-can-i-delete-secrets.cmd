oc auth can-i delete secrets -n fds-app --request-timeout=20s 
