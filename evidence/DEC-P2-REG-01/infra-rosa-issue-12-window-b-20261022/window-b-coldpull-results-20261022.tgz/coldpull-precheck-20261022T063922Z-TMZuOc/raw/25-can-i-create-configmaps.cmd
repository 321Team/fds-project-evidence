oc auth can-i create configmaps -n fds-app --request-timeout=20s 
