oc auth can-i get events -n fds-app --request-timeout=20s 
