oc get pods\,configmaps\,secrets -n fds-app -l app.kubernetes.io/part-of=fds-coldpull --request-timeout=20s -o name 
