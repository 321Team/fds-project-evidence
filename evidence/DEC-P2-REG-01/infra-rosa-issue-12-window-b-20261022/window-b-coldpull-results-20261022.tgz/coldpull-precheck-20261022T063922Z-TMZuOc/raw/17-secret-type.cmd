oc get secret p2-coldpull-harbor-pull -n fds-app --request-timeout=20s -o jsonpath=\{.type\}\{\"\ \"\}\{.metadata.creationTimestamp\} 
