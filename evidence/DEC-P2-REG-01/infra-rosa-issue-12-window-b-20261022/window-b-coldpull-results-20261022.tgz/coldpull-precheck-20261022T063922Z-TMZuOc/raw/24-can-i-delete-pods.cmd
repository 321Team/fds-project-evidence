oc auth can-i delete pods -n fds-app --request-timeout=20s 
