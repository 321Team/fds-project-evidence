python3 /home/cloudshell-user/wb/kit/coldpull_tool.py sa-secrets /home/cloudshell-user/coldpull-precheck-20261022T063922Z-TMZuOc/sa-default.json p2-coldpull-harbor-pull 
