python3 /home/cloudshell-user/wb/kit/coldpull_tool.py trust-keys /home/cloudshell-user/coldpull-precheck-20261022T063922Z-TMZuOc/describe.json 10.1.93.54 harbor.fds.internal 
