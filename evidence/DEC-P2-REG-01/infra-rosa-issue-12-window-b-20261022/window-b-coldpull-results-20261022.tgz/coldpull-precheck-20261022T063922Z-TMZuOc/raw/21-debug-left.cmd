oc get pods -n fds-app --request-timeout=20s -o name 
