oc get configmap fds-cp-ca-g4axs1 -n fds-app --request-timeout=20s -o name 
