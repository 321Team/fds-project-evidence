oc create -f /home/cloudshell-user/coldpull-path-before-20261022T064006Z-G4aXs1/pod-tool.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
