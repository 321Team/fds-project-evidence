oc create -f /home/cloudshell-user/coldpull-path-before-20261022T064006Z-G4aXs1/cm.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
