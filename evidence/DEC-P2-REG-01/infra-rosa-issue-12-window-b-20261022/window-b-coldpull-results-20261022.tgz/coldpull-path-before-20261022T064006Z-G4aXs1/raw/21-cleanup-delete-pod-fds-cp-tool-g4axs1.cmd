oc delete pod fds-cp-tool-g4axs1 -n fds-app --wait=true --timeout=120s --request-timeout=20s 
