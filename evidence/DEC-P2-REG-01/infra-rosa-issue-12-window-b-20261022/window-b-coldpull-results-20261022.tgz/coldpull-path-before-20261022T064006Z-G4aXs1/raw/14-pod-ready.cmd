python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-tool-g4axs1 ready 300 /home/cloudshell-user/coldpull-path-before-20261022T064006Z-G4aXs1/pod-tool-status.json 20 
