oc get pod fds-cp-tool-g4axs1 -n fds-app --request-timeout=20s -o jsonpath=\{.spec.nodeName\}\{\"\ \"\}\{.status.hostIP\} 
