oc delete configmap fds-cp-ca-g4axs1 -n fds-app --wait=true --timeout=120s --request-timeout=20s 
