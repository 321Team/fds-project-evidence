oc get events -n fds-app --request-timeout=20s --field-selector involvedObject.uid=ccdaf3a2-ac15-4745-bfc2-2155a1822ec8 -o json 
