python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-a2-sj8fym pullfail 240 /home/cloudshell-user/coldpull-pull-20261022T084552Z-SJ8fym/pod-A2-status.json 20 
