oc get events -n fds-app --request-timeout=20s --field-selector involvedObject.uid=fcf78a2b-99d6-4898-8350-5c43aee1d4c7 -o json 
