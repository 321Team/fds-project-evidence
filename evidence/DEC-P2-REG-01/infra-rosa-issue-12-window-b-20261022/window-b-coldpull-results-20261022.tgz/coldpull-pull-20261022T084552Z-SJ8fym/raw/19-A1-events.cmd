oc get events -n fds-app --request-timeout=20s --field-selector involvedObject.uid=6fd17a4e-1e53-40fd-a8c1-3e19215245d8 -o json 
