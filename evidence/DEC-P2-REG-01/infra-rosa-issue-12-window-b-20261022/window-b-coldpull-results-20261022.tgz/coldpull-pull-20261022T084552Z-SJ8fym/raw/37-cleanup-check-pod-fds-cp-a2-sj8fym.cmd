oc get pod fds-cp-a2-sj8fym -n fds-app --request-timeout=20s -o name 
