python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-c2-sj8fym pulled 900 /home/cloudshell-user/coldpull-pull-20261022T084552Z-SJ8fym/pod-C2-status.json 20 
