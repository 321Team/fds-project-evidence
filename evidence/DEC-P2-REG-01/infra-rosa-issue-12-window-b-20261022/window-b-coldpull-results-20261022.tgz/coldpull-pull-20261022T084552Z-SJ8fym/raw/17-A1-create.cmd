oc create -f /home/cloudshell-user/coldpull-pull-20261022T084552Z-SJ8fym/pod-A1.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
