python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-c2-sj8fym running 180 /home/cloudshell-user/coldpull-pull-20261022T084552Z-SJ8fym/pod-C2-run-status.json 20 
