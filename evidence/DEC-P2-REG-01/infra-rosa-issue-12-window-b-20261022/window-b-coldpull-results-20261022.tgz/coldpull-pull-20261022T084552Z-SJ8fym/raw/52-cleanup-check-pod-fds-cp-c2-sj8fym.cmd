oc get pod fds-cp-c2-sj8fym -n fds-app --request-timeout=20s -o name 
