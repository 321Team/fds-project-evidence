oc delete secret fds-cp-wrong-sj8fym -n fds-app --wait=true --timeout=120s --request-timeout=20s 
