bash -c set\ -euo\ pipefail\;\ cd\ \'/home/cloudshell-user/coldpull-path-after-20261022T083333Z-bGuG1n\'\ \&\&\ sha256sum\ -c\ --quiet\ SHA256SUMS 
