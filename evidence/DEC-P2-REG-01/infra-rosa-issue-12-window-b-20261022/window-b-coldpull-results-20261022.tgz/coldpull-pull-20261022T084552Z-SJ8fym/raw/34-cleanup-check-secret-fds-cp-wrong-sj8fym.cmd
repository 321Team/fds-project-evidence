oc get secret fds-cp-wrong-sj8fym -n fds-app --request-timeout=20s -o name 
