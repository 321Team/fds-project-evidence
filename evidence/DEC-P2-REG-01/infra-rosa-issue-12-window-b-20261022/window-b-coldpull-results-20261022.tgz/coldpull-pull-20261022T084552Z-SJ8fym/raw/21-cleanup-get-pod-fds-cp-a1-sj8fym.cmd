oc get pod fds-cp-a1-sj8fym -n fds-app --request-timeout=20s -o jsonpath=\{.metadata.uid\}\{\"\ \"\}\{.metadata.labels.fds-coldpull-run\} 
