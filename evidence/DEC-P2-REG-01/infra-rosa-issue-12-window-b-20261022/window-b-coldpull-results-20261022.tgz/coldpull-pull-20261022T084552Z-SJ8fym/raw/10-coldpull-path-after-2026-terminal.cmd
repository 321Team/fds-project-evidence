python3 - /home/cloudshell-user/coldpull-path-after-20261022T083333Z-bGuG1n/ledger.txt coldpull-path-after 
