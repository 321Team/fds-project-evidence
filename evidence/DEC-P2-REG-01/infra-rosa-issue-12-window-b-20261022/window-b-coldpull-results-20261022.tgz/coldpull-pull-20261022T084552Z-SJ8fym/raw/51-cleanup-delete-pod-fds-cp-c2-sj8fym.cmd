oc delete pod fds-cp-c2-sj8fym -n fds-app --wait=true --timeout=120s --request-timeout=20s 
