oc delete pod fds-cp-a2-sj8fym -n fds-app --wait=true --timeout=120s --request-timeout=20s 
