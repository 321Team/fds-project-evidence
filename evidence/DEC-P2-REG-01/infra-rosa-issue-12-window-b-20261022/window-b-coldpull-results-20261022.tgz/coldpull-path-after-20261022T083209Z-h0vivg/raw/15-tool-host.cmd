oc get pod fds-cp-tool-h0vivg -n fds-app --request-timeout=20s -o jsonpath=\{.spec.nodeName\}\{\"\ \"\}\{.status.hostIP\} 
