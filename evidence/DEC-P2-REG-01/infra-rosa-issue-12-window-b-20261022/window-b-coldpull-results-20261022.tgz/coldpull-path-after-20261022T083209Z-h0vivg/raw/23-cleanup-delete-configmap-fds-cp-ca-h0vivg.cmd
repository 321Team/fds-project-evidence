oc delete configmap fds-cp-ca-h0vivg -n fds-app --wait=true --timeout=120s --request-timeout=20s 
