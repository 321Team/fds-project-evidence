oc delete pod fds-cp-tool-h0vivg -n fds-app --wait=true --timeout=120s --request-timeout=20s 
