oc get pod fds-cp-tool-h0vivg -n fds-app --request-timeout=20s -o jsonpath=\{.metadata.uid\}\{\"\ \"\}\{.metadata.labels.fds-coldpull-run\} 
