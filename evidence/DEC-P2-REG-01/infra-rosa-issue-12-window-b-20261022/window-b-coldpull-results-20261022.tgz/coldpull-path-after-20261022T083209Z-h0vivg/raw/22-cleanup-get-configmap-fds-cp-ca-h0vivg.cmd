oc get configmap fds-cp-ca-h0vivg -n fds-app --request-timeout=20s -o jsonpath=\{.metadata.uid\}\{\"\ \"\}\{.metadata.labels.fds-coldpull-run\} 
