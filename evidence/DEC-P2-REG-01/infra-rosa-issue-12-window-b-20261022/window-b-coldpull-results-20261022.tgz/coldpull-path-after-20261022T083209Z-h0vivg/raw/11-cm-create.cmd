oc create -f /home/cloudshell-user/coldpull-path-after-20261022T083209Z-h0vivg/cm.json --request-timeout=20s -o jsonpath=\{.metadata.uid\} 
