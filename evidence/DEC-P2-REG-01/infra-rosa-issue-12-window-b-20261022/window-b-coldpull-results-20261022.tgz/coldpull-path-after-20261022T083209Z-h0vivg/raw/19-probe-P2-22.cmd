timeout 40 oc exec -n fds-app fds-cp-tool-h0vivg -- bash -c $'{ timeout 10 bash -c \'exec 3<>/dev/tcp/10.1.93.54/22\'\n}; r=$?; echo; echo PROBE_RC=$r' 
