python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-tool-h0vivg ready 300 /home/cloudshell-user/coldpull-path-after-20261022T083209Z-h0vivg/pod-tool-status.json 20 
