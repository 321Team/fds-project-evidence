python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-tool-mktuv4 ready 300 /home/cloudshell-user/coldpull-path-before-20261022T064152Z-mkTUv4/pod-tool-status.json 20 
