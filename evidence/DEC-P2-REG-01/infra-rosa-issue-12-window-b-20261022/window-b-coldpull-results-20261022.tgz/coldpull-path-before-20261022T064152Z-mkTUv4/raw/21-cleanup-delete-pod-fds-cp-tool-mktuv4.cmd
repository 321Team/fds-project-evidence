oc delete pod fds-cp-tool-mktuv4 -n fds-app --wait=true --timeout=120s --request-timeout=20s 
