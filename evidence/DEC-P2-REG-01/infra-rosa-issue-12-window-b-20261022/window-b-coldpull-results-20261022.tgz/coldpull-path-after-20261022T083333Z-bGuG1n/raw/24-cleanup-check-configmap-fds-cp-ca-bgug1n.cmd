oc get configmap fds-cp-ca-bgug1n -n fds-app --request-timeout=20s -o name 
