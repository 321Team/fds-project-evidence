oc delete configmap fds-cp-ca-bgug1n -n fds-app --wait=true --timeout=120s --request-timeout=20s 
