timeout 40 oc exec -n fds-app fds-cp-tool-bgug1n -- bash -c $'{ timeout 10 bash -c \'exec 3<>/dev/tcp/10.1.93.50/443\'\n}; r=$?; echo; echo PROBE_RC=$r' 
