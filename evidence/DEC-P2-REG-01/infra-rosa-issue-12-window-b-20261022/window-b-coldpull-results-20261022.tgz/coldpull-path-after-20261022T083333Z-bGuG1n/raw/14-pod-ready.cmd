python3 /home/cloudshell-user/wb/kit/coldpull_tool.py wait fds-app fds-cp-tool-bgug1n ready 300 /home/cloudshell-user/coldpull-path-after-20261022T083333Z-bGuG1n/pod-tool-status.json 20 
