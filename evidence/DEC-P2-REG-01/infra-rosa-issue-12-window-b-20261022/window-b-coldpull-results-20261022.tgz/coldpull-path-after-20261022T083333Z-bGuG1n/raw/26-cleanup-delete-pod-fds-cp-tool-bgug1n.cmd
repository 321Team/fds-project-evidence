oc delete pod fds-cp-tool-bgug1n -n fds-app --wait=true --timeout=120s --request-timeout=20s 
