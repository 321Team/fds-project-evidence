oc get pod fds-cp-tool-bgug1n -n fds-app --request-timeout=20s -o jsonpath=\{.spec.nodeName\}\{\"\ \"\}\{.status.hostIP\} 
