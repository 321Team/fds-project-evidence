python3 - /home/cloudshell-user/coldpull-precheck-20261022T064121Z-YstgFr/ledger.txt coldpull-precheck 
