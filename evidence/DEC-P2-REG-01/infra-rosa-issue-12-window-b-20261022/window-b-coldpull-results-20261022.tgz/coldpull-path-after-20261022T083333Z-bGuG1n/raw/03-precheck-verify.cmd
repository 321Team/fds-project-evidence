bash -c set\ -euo\ pipefail\;\ cd\ \'/home/cloudshell-user/coldpull-precheck-20261022T064121Z-YstgFr\'\ \&\&\ sha256sum\ -c\ --quiet\ SHA256SUMS 
