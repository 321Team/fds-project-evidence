#!/bin/sh
# record.sh NAME COMMAND [ARG...]
# Runs COMMAND once and keeps its start time, stdout, stderr and exit code in
#   $IF06B_RESULTS/NAME.time  NAME.out  NAME.err  NAME.rc
# A NAME that was already used is refused (rc 97) and COMMAND is not run, so a
# result is never overwritten. The exit code is COMMAND's own, not a pipe's.
# Do not use this for a command whose stdout is a secret.
set -u
[ "$#" -ge 2 ] || { echo "record: usage NAME COMMAND..." >&2; exit 98; }
name=$1
shift
case $name in
  *[!A-Za-z0-9._-]*|'') echo "record: bad name" >&2; exit 98 ;;
esac
dir=${IF06B_RESULTS:?record: IF06B_RESULTS is not set}
[ -d "$dir" ] || { echo "record: results directory missing" >&2; exit 98; }
umask 077
set -C
if ! date -Is > "$dir/$name.time" 2>/dev/null; then
  echo "record: $name already recorded; nothing was run" >&2
  exit 97
fi
"$@" > "$dir/$name.out" 2> "$dir/$name.err"
rc=$?
echo "$rc" > "$dir/$name.rc"
echo "$name rc=$rc"
exit "$rc"
