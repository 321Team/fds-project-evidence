"""Read-only: summarise ONE saved API response without trusting the command's exit code.

Usage: objinfo.py RESPONSE_FILE KIND NAME [NAMESPACE]
  rc0  OBJECT_OK kind= name= namespace= uid= rv= spec_sha256= finalizers= deleting=
  rc4  STATUS reason= code=          the file is a Kubernetes Status (NotFound, Forbidden, ...)
  rc3  STOP_...                      empty, not JSON, or another object than the one named
The spec hash uses the same canonical JSON as decision.spec_hash. Nothing is sent.
"""
import hashlib
import json
import pathlib
import sys


def end(text, rc):
    print(text)
    raise SystemExit(rc)


try:
    path, kind, name = sys.argv[1], sys.argv[2], sys.argv[3]
    namespace = sys.argv[4] if len(sys.argv) > 4 else None
    raw = pathlib.Path(path).read_bytes()
    if not raw.strip():
        end('STOP_EMPTY_RESPONSE', 3)
    try:
        body = json.loads(raw)
    except ValueError:
        end('STOP_NOT_JSON', 3)
    if not isinstance(body, dict):
        end('STOP_NOT_JSON', 3)
    if body.get('kind') == 'Status':
        end('STATUS reason=%s code=%s' % (body.get('reason'), body.get('code')), 4)
    meta = body.get('metadata')
    if body.get('kind') != kind or not isinstance(meta, dict) or meta.get('name') != name:
        end('STOP_NOT_EXPECTED_OBJECT', 3)
    if meta.get('namespace') != namespace:
        end('STOP_NOT_EXPECTED_NAMESPACE', 3)
    uid = meta.get('uid')
    if not isinstance(uid, str) or not uid:
        end('STOP_NO_UID', 3)
    spec = body.get('spec')
    digest = None
    if isinstance(spec, dict) and spec:
        digest = hashlib.sha256(json.dumps(spec, sort_keys=True, separators=(',', ':'),
                                           ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    end('OBJECT_OK kind=%s name=%s namespace=%s uid=%s rv=%s spec_sha256=%s finalizers=%s deleting=%s' % (
        kind, name, namespace, uid, meta.get('resourceVersion'), digest,
        bool(meta.get('finalizers')), bool(meta.get('deletionTimestamp'))), 0)
except (OSError, IndexError, TypeError, ValueError):
    end('STOP_UNREADABLE', 3)
