"""Read-only: print the non-secret claims of a token file and judge its lifetime.

Usage: tokeninfo.py TOKEN_FILE EXPECTED_SUB EXPECTED_SA_UID MAX_LIFETIME_S NEED_S
  rc0  TOKEN_CLAIMS_OK ...
  rc3  STOP_TOKEN_...            do not start a run with this token
The token itself is never printed. Decoding is not authentication: only preflight,
with the real credential, shows that the API accepts it and what it may do.
"""
import base64
import json
import math
import pathlib
import sys
import time


def end(text, rc):
    print(text)
    raise SystemExit(rc)


try:
    expected_sub, expected_uid = sys.argv[2], sys.argv[3]
    longest, need = float(sys.argv[4]), float(sys.argv[5])
    if not (math.isfinite(longest) and math.isfinite(need) and longest > 0 and need > 0):
        end('STOP_TOKEN_ARGUMENTS', 3)
    parts = pathlib.Path(sys.argv[1]).read_text(encoding='ascii').strip().split('.')
    if len(parts) != 3:
        end('STOP_TOKEN_FORMAT', 3)
    claims = json.loads(base64.urlsafe_b64decode(parts[1] + '=' * (-len(parts[1]) % 4)))
    issued, expires = claims['iat'], claims['exp']
    if type(issued) not in (int, float) or type(expires) not in (int, float) or expires <= issued:
        end('STOP_TOKEN_FORMAT', 3)
    account = claims.get('kubernetes.io', {}).get('serviceaccount', {})
    lifetime, left = expires - issued, expires - time.time()
    summary = 'sub=%s aud=%s iat=%s exp=%s lifetime_s=%s left_s=%s' % (
        claims.get('sub'), claims.get('aud'), issued, expires, round(lifetime), round(left))
    if claims.get('sub') != expected_sub:
        end('STOP_TOKEN_SUBJECT ' + summary, 3)
    if account.get('uid') != expected_uid:
        end('STOP_TOKEN_SA_UID ' + summary, 3)
    if lifetime > longest:
        end('STOP_TOKEN_LIFETIME_EXCEEDS ' + summary, 3)
    if left < need:
        end('STOP_TOKEN_TOO_SHORT ' + summary, 3)
    end('TOKEN_CLAIMS_OK ' + summary, 0)
except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError):
    end('STOP_TOKEN_UNREADABLE', 3)
