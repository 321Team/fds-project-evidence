"""Read-only: is THIS session's guardian still the process named in its own ARMING row?

Usage: ident.py INPUT_JSON SUPERVISOR_JSONL
  rc0  GUARDIAN_ALIVE pid=N      only then may a signal be sent to N
  rc4  GUARDIAN_GONE ...         the recorded process no longer exists as recorded
  rc3  STOP_...                  wrong session/boot or unreadable state: send nothing
Nothing is written, signalled or sent. An answer is true only at the moment of reading.
"""
import json
import pathlib
import sys


def end(text, rc):
    print(text)
    raise SystemExit(rc)


try:
    cfg = json.loads(pathlib.Path(sys.argv[1]).read_bytes())
    raw = pathlib.Path(sys.argv[2]).read_bytes()
    if b'\n' not in raw:
        end('STOP_NO_COMPLETE_ARMING', 3)
    first = json.loads(raw.split(b'\n', 1)[0])
    if first.get('step') != 'ARMING' or first.get('seq') != 1:
        end('STOP_UNEXPECTED_HISTORY', 3)
    binding = first['binding']
    if binding['session_id'] != cfg['session_id'] or binding['cluster_uid'] != cfg['expected_cluster_uid']:
        end('STOP_WRONG_SESSION', 3)
    if binding['host_boot_id'] != pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip():
        end('STOP_WRONG_BOOT', 3)
    pid, started = binding['guardian_epoch'].split('-')
    if not pid.isdecimal() or not started.isdecimal() or int(pid) <= 0:
        end('STOP_PROCESS_IDENTITY', 3)
    try:
        fields = pathlib.Path('/proc', pid, 'stat').read_bytes().rsplit(b')', 1)[1].split()
    except FileNotFoundError:
        end('GUARDIAN_GONE no_such_process recorded_pid=' + pid, 4)
    if fields[19].decode() != started:
        end('GUARDIAN_GONE pid_reused_by_another_process recorded_pid=' + pid, 4)
    if fields[0] in (b'Z', b'X', b'x'):
        end('GUARDIAN_GONE exited_not_reaped recorded_pid=' + pid, 4)
    end('GUARDIAN_ALIVE pid=' + pid, 0)
except (OSError, ValueError, KeyError, TypeError, IndexError):
    end('STOP_UNREADABLE_STATE', 3)
