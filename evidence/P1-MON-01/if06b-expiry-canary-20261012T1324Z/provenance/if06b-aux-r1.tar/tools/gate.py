import json, math, pathlib, sys, time
def stop(reason):
    print(reason)
    raise SystemExit(3)
try:
    cfg = json.loads(pathlib.Path(sys.argv[1]).read_bytes())
    raw = pathlib.Path(sys.argv[2]).read_bytes()
    if not raw or not raw.endswith(b'\n'):
        stop('WAIT_NO_COMPLETE_SNAPSHOT')
    rows = [json.loads(x) for x in raw.splitlines()]
    if [r.get('seq') for r in rows] != list(range(1, len(rows) + 1)):
        stop('STOP_EVIDENCE_SEQUENCE')
    steps = [r.get('step') for r in rows]
    if any(s in steps for s in ('TRIGGER', 'CLEANUP', 'READBACK', 'FINAL')):
        stop('STOP_RECLAIM_OR_TERMINAL')
    if steps not in (['ARMING'], ['ARMING', 'ARMED'], ['ARMING', 'ARMED', 'CREATE']):
        stop('STOP_UNEXPECTED_HISTORY')
    a = rows[0]
    b = a['binding']
    if b['session_id'] != cfg['session_id'] or b['cluster_uid'] != cfg['expected_cluster_uid']:
        stop('STOP_WRONG_SESSION')
    if b['host_boot_id'] != pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip():
        stop('STOP_WRONG_BOOT')
    pid, started = b['guardian_epoch'].split('-')
    if not pid.isdecimal() or not started.isdecimal() or int(pid) <= 0:
        stop('STOP_PROCESS_IDENTITY')
    fields = pathlib.Path('/proc', pid, 'stat').read_bytes().rsplit(b')', 1)[1].split()
    if fields[19].decode() != started or fields[0] in (b'Z', b'X', b'x'):
        stop('STOP_PROCESS_IDENTITY')
    need = float(sys.argv[3])
    now = time.clock_gettime(time.CLOCK_BOOTTIME)
    expires = a['expires_mono']
    if not math.isfinite(need) or need <= 0 or not math.isfinite(expires) or expires - now <= need:
        stop('STOP_INSUFFICIENT_LEASE')
    if steps[-1] != 'CREATE':
        stop('WAIT_CREATE')
    c = rows[-1]
    if c.get('action') != 'OWNED' or not c.get('uid') or not c.get('resource_version'):
        stop('STOP_NOT_OWNED')
    print('SNAPSHOT_ELIGIBLE', 'pid=' + pid, 'start_remaining_s=', expires - now - need)
except (OSError, ValueError, KeyError, TypeError, IndexError):
    stop('STOP_UNREADABLE_STATE')
