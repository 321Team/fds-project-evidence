# CR-P1-NTP-01-01 Evidence Index

- Generated: 20260921T105519+0900
- Repository: 321Team/infra-ansible
- Commit: 0e17e2d7713484352c84f72d9ddc55aab6187386

## Files
- `20260921T105247+0900_precheck.iSLt2O.txt`
- `20260921T105304+0900_source_apply.HcyzNS.txt`
- `20260921T105304+0900_source_check_diff.NXBo8a.txt`
- `20260921T105304+0900_source_idempotency.OLJpsX.txt`
- `20260921T105332+0900_clients_apply.Ev2bGw.txt`
- `20260921T105332+0900_clients_check_diff.MoLIk6.txt`
- `20260921T105332+0900_clients_idempotency.ezVcEP.txt`
- `20260921T105513+0900_verify_all_nodes.rqlrUY.txt`
- `SOURCE_HEAD`
