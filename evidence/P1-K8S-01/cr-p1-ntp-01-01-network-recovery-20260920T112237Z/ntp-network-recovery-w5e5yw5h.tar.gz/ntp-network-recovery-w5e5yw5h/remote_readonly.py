#!/usr/bin/env python3
"""Fixed-scope, read-only NTP network/recovery evidence payload.

Executed from stdin by Ansible's command module under become.  This module does
not create files, send NTP probes, modify policy, restart services, or decide
deployment readiness.  stdout is exactly one JSON document.
"""

import base64
import datetime
import errno
import hashlib
import ipaddress
import json
import os
import re
import selectors
import shutil
import signal
import socket
import stat
import subprocess
import time


HOSTS = {
    "k8s-control01": "10.1.93.102",
    "k8s-control02": "10.1.93.103",
    "k8s-control03": "10.1.93.104",
    "k8s-worker01": "10.1.93.105",
    "k8s-worker02": "10.1.93.107",
    "k8s-worker03": "10.1.93.108",
}
UPSTREAMS = ("162.159.200.1", "162.159.200.123")
SAFE_PATH = "/usr/sbin:/usr/bin:/sbin:/bin"
NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\Z")
COMMAND_LIMIT = 2 * 1024 * 1024
FILE_LIMIT = 1024 * 1024
MAX_FILES = 256
MAX_DEPTH = 5
TOTAL_FILE_LIMIT = 12 * 1024 * 1024
TOTAL_COMMAND_LIMIT = 16 * 1024 * 1024
COLLECTION_TIMEOUT = 300
MAIN_PATH = "/etc/chrony.conf"
DROPIN_PATH = "/etc/chrony.d/50-cr-p1-ntp-01-01.conf"
STATE_DIR = "/var/lib/fds-change/CR-P1-NTP-01-01"


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run_command(argv, timeout=15, limit=COMMAND_LIMIT):
    """Run fixed argv, retain bounded output, kill its process group on timeout.

    Output beyond the retention bound is drained without retaining it.  There
    are no shell commands, temporary files, or unbounded communicate() buffers.
    """
    start = time.monotonic()
    result = {
        "argv": list(argv), "started_at": utc_now(), "rc": None,
        "timed_out": False, "truncated": False, "stdout": "", "stderr": "",
        "stdout_bytes": 0, "stderr_bytes": 0,
    }
    environment = {"PATH": SAFE_PATH, "LANG": "C", "LC_ALL": "C"}
    try:
        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                env=environment, start_new_session=True)
    except OSError as exc:
        result.update(error=str(exc), error_type=type(exc).__name__)
        result["ended_at"] = utc_now()
        result["duration_seconds"] = round(time.monotonic() - start, 3)
        return result
    streams = {"stdout": bytearray(), "stderr": bytearray()}
    selector = selectors.DefaultSelector()
    for stream, label in ((proc.stdout, "stdout"), (proc.stderr, "stderr")):
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, label)
    deadline = start + timeout
    killed_at = None
    try:
        while selector.get_map():
            now = time.monotonic()
            if now >= deadline and killed_at is None:
                result["timed_out"] = True
                killed_at = now
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            # A descendant escaping the group must not keep a pipe open forever.
            if killed_at is not None and now - killed_at > 2:
                result["truncated"] = True
                break
            for key, unused_events in selector.select(0.15):
                try:
                    chunk = os.read(key.fileobj.fileno(), 65536)
                except BlockingIOError:
                    continue
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                label = key.data
                result[label + "_bytes"] += len(chunk)
                remaining = max(0, limit - len(streams[label]))
                streams[label].extend(chunk[:remaining])
                if len(chunk) > remaining:
                    result["truncated"] = True
        try:
            result["rc"] = proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            result["timed_out"] = True
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            result["rc"] = proc.wait(timeout=2)
    finally:
        selector.close()
        for stream in (proc.stdout, proc.stderr):
            if not stream.closed:
                stream.close()
    for label in streams:
        result[label] = bytes(streams[label]).decode("utf-8", "replace")
    result["ended_at"] = utc_now()
    result["duration_seconds"] = round(time.monotonic() - start, 3)
    return result


def stat_metadata(value):
    return {
        "uid": value.st_uid, "gid": value.st_gid,
        "mode": format(stat.S_IMODE(value.st_mode), "04o"),
        "size": value.st_size, "nlink": value.st_nlink,
        "mtime_ns": value.st_mtime_ns, "ctime_ns": value.st_ctime_ns,
        "device": value.st_dev, "inode": value.st_ino,
    }


def secure_open(path, directory=False):
    """Open every component relative to an O_NOFOLLOW directory descriptor."""
    if not isinstance(path, str) or not path.startswith("/"):
        raise ValueError("Absolute path required")
    parts = path.split("/")[1:]
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise ValueError("Non-canonical path")
    current = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for index, part in enumerate(parts):
            is_directory = index < len(parts) - 1 or directory
            flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW
            if is_directory:
                flags |= os.O_DIRECTORY
            else:
                flags |= os.O_NONBLOCK
            nxt = os.open(part, flags, dir_fd=current)
            os.close(current)
            current = nxt
        result = current
        current = None
        return result
    finally:
        if current is not None:
            os.close(current)


def error_status(exc):
    if isinstance(exc, FileNotFoundError):
        return "ABSENT"
    if isinstance(exc, OSError) and exc.errno in (errno.ELOOP, errno.ENOTDIR):
        return "UNSAFE"
    return "ERROR"


def safe_sysconfig(data):
    """Only retain expected chronyd options, never arbitrary environment values."""
    try:
        lines = data.decode("utf-8").splitlines()
    except UnicodeError:
        return False
    for line in lines:
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if not re.fullmatch(r"OPTIONS\s*=\s*[\"']?[-A-Za-z0-9 /_.=]*[\"']?", text):
            return False
    return True


def snapshot_file(path, limit=FILE_LIMIT):
    result = {"collected_at": utc_now(), "status": "ERROR"}
    fd = None
    try:
        fd = secure_open(path)
        before = os.fstat(fd)
        result["stat"] = stat_metadata(before)
        if not stat.S_ISREG(before.st_mode):
            result.update(status="UNSAFE", error="Not a regular file")
            return result
        if before.st_nlink != 1:
            result.update(status="UNSAFE", error="Hardlinked file rejected")
            return result
        if before.st_size > limit:
            result.update(status="TRUNCATED", error="File exceeds capture bound")
            return result
        chunks = bytearray()
        while len(chunks) <= limit:
            chunk = os.read(fd, min(65536, limit + 1 - len(chunks)))
            if not chunk:
                break
            chunks.extend(chunk)
        after = os.fstat(fd)
        if len(chunks) > limit:
            result.update(status="TRUNCATED", error="File grew past capture bound")
            return result
        if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            result.update(status="ERROR", error="File changed during capture")
            return result
        data = bytes(chunks)
        result.update(status="PRESENT", sha256=hashlib.sha256(data).hexdigest(),
                      captured_bytes=len(data))
        try:
            result["selinux_context"] = os.getxattr(fd, "security.selinux").decode("utf-8", "replace").rstrip("\0")
        except OSError as exc:
            result["selinux_context_error"] = str(exc)
        if path == "/etc/sysconfig/chronyd" and not safe_sysconfig(data):
            result["content_withheld"] = True
            result["content_withheld_reason"] = "Unexpected sysconfig content; possible environment secrets"
        else:
            result["base64"] = base64.b64encode(data).decode("ascii")
        return result
    except (OSError, ValueError) as exc:
        result.update(status=error_status(exc), error=str(exc))
        return result
    finally:
        if fd is not None:
            os.close(fd)


def inventory_tree(root, suffixes=None, max_files=MAX_FILES, max_depth=MAX_DEPTH):
    """Bounded tree inventory without following any symlink or special file."""
    entries, eligible = [], []
    result = {"root": root, "status": "PRESENT", "entries": entries,
              "truncated": False, "collected_at": utc_now()}
    count = 0

    def visit(path, depth):
        nonlocal count
        descriptor = secure_open(path, directory=True)
        try:
            # scandir(fd) does not reopen the path, and inode types are not followed.
            with os.scandir(descriptor) as iterator:
                for entry in iterator:
                    count += 1
                    if count > max_files:
                        result["truncated"] = True
                        return
                    child = path + "/" + entry.name
                    metadata = entry.stat(follow_symlinks=False)
                    item = {"path": child, "stat": stat_metadata(metadata)}
                    entries.append(item)
                    if stat.S_ISLNK(metadata.st_mode):
                        item["type"] = "SYMLINK_REJECTED"
                    elif stat.S_ISDIR(metadata.st_mode):
                        item["type"] = "DIRECTORY"
                        if depth >= max_depth:
                            item["status"] = "DEPTH_LIMIT"
                            result["truncated"] = True
                        else:
                            try:
                                visit(child, depth + 1)
                            except (OSError, ValueError) as exc:
                                item.update(status=error_status(exc), error=str(exc))
                    elif stat.S_ISREG(metadata.st_mode):
                        item["type"] = "REGULAR"
                        if suffixes is None or any(entry.name.endswith(s) for s in suffixes):
                            eligible.append(child)
                        else:
                            item["content"] = "OUTSIDE_ALLOWLIST"
                    else:
                        item["type"] = "SPECIAL_REJECTED"
        finally:
            os.close(descriptor)

    try:
        visit(root, 0)
    except (OSError, ValueError) as exc:
        result.update(status=error_status(exc), error=str(exc))
    return result, sorted(eligible)


def valid_command(result):
    return result.get("rc") == 0 and not result.get("timed_out") and not result.get("truncated")


def identity_from(hostname, address_result):
    short = hostname.split(".", 1)[0]
    addresses = []
    error = None
    if valid_command(address_result):
        try:
            for interface in json.loads(address_result["stdout"]):
                for address in interface.get("addr_info", []):
                    value = address.get("local")
                    if value:
                        addresses.append(str(ipaddress.ip_address(value)))
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            error = "Invalid address JSON: " + str(exc)
    else:
        error = "Address command failed or was incomplete"
    expected = HOSTS.get(short)
    owned_project_addresses = set(addresses).intersection(HOSTS.values())
    valid = bool(expected and expected in addresses and owned_project_addresses == {expected} and not error)
    return {"hostname": hostname, "short_hostname": short,
            "addresses": sorted(set(addresses)), "expected_address": expected,
            "valid": valid, "error": error}


class Collector:
    def __init__(self, runner=run_command, hostname=None, file_reader=snapshot_file,
                 tree_reader=inventory_tree, which=None):
        self.runner = runner
        self.hostname = hostname if hostname is not None else socket.gethostname()
        self.file_reader = file_reader
        self.tree_reader = tree_reader
        self.which = which if which is not None else lambda name: shutil.which(name, path=SAFE_PATH)
        self.result = {
            "schema_version": 1, "started_at": utc_now(), "host": self.hostname.split(".", 1)[0],
            "expected_address": HOSTS.get(self.hostname.split(".", 1)[0]),
            "identity": {}, "commands": {}, "files": {}, "inventories": {}, "gaps": [],
            "limitations": [
                "Read-only collection does not authorize policy changes or establish deployment readiness.",
                "Upstream routers/firewalls, return NAT, and out-of-band recovery access are not observable from these host snapshots.",
                "No external or internal NTP test packets are sent; path reachability is not proven.",
                "Missing pre-apply listener/ACL/pair baseline is an observation, not an automatic deployment failure.",
                "Sequential snapshots are not atomic across services, files, hosts, or the Kubernetes API.",
            ],
        }
        self.file_bytes = 0
        self.command_bytes = 0
        self.deadline = time.monotonic() + COLLECTION_TIMEOUT
        self.runtime_identity = {"uid": os.getuid(), "euid": os.geteuid(),
                                 "gid": os.getgid(), "egid": os.getegid()}

    def gap(self, label, reason, required=True):
        self.result["gaps"].append({"label": label, "reason": reason, "required": required})

    def observe(self, label, argv, required=False, timeout=15):
        remaining = TOTAL_COMMAND_LIMIT - self.command_bytes
        seconds_left = self.deadline - time.monotonic()
        if seconds_left <= 0:
            required = True
            result = {"argv": list(argv), "rc": None, "timed_out": True,
                      "truncated": False, "stdout": "", "stderr": "",
                      "error": "Global collection deadline reached; command not executed",
                      "started_at": utc_now(), "ended_at": utc_now()}
        elif remaining <= 0:
            result = {"argv": list(argv), "rc": None, "timed_out": False,
                      "truncated": True, "stdout": "", "stderr": "",
                      "error": "Total command capture bound reached",
                      "started_at": utc_now(), "ended_at": utc_now()}
        else:
            # Each stream receives half the remaining aggregate allowance.
            result = self.runner(argv, timeout=min(timeout, seconds_left), limit=min(COMMAND_LIMIT, max(1, remaining // 2)))
            self.command_bytes += len(result.get("stdout", "").encode("utf-8")) + len(result.get("stderr", "").encode("utf-8"))
        result["required"] = required
        self.result["commands"][label] = result
        if not valid_command(result):
            self.gap(label, "Command unavailable, failed, timed out, or output truncated", required)
        return result

    def command(self, label, name, args, required=False, timeout=15):
        executable = self.which(name)
        if executable is None:
            result = {"argv": [name] + list(args), "rc": None, "timed_out": False,
                      "truncated": False, "stdout": "", "stderr": "",
                      "required": required, "error": "Executable not installed in fixed PATH",
                      "started_at": utc_now(), "ended_at": utc_now()}
            self.result["commands"][label] = result
            self.gap(label, "Executable unavailable", required)
            return result
        return self.observe(label, [executable] + list(args), required, timeout)

    def capture(self, path, required=False):
        if path in self.result["files"]:
            return self.result["files"][path]
        remaining = TOTAL_FILE_LIMIT - self.file_bytes
        if time.monotonic() >= self.deadline:
            result = {"status": "ERROR", "error": "Global collection deadline reached; file not read"}
        elif remaining <= 0:
            result = {"status": "TRUNCATED", "error": "Total file capture bound reached"}
        else:
            result = self.file_reader(path, limit=min(FILE_LIMIT, remaining))
        result["required"] = required
        self.result["files"][path] = result
        self.file_bytes += result.get("captured_bytes", 0)
        if result["status"] not in ("PRESENT", "ABSENT") or (required and result["status"] == "ABSENT") or result.get("content_withheld"):
            self.gap(path, result.get("error", result.get("content_withheld_reason", "Required file missing")), required or result["status"] != "ABSENT")
        return result

    def capture_tree(self, path, suffixes=None, required=False):
        if time.monotonic() >= self.deadline:
            self.result["inventories"][path] = {"root": path, "status": "ERROR",
                "entries": [], "truncated": False, "error": "Global collection deadline reached"}
            self.gap(path, "Global collection deadline reached; tree not read", True)
            return
        inventory, paths = self.tree_reader(path, suffixes=suffixes)
        self.result["inventories"][path] = inventory
        if inventory["status"] not in ("PRESENT", "ABSENT") or inventory.get("truncated"):
            self.gap(path, "Directory inventory unsafe, incomplete, or truncated", True)
        for entry in inventory.get("entries", []):
            if entry.get("type") in ("SYMLINK_REJECTED", "SPECIAL_REJECTED") or entry.get("status"):
                self.gap(entry["path"], "Directory entry not safely captured", True)
        for name in paths:
            self.capture(name, required=required)

    def firewalld(self):
        state = self.command("firewalld_state", "firewall-cmd", ["--state"])
        active = valid_command(state) and state["stdout"].strip() == "running"
        self.result["firewalld_running"] = active
        for permanent in (False, True):
            prefix = "firewalld_permanent" if permanent else "firewalld_runtime"
            mode = ["--permanent"] if permanent else []
            self.command(prefix + "_zones", "firewall-cmd", mode + ["--list-all-zones"], active)
            if not permanent:
                self.command(prefix + "_active_zones", "firewall-cmd", ["--get-active-zones"], active)
            self.command(prefix + "_default_zone", "firewall-cmd", mode + ["--get-default-zone"], active)
            for kind in ("chains", "rules"):
                self.command(prefix + "_direct_" + kind, "firewall-cmd", mode + ["--direct", "--get-all-" + kind], active)
            for family in ("ipv4", "ipv6", "eb"):
                self.command(prefix + "_passthrough_" + family, "firewall-cmd", mode + ["--direct", "--get-passthroughs", family], active)
            policies = self.command(prefix + "_policies", "firewall-cmd", mode + ["--get-policies"], active)
            if valid_command(policies):
                names = policies["stdout"].split()
                if len(names) > 128 or any(not NAME_RE.fullmatch(name) for name in names):
                    self.gap(prefix + "_policies", "Unsafe or excessive policy names", True)
                else:
                    for name in sorted(set(names)):
                        self.command(prefix + "_policy_" + name, "firewall-cmd", mode + ["--policy=" + name, "--list-all"], active)
        # On an inactive service the disk snapshots remain authoritative evidence
        # to review.  Do not invoke firewall-offline-cmd or start firewalld.
        if not active:
            self.gap("firewalld_runtime", "firewalld is unavailable/not running; inspect effective nftables and disk policy", False)
        self.capture_tree("/etc/firewalld", suffixes=(".xml", ".conf"))

    def chrony(self):
        self.command("chrony_rpm", "rpm", ["-q", "chrony"], True)
        self.command("chronyd_version", "chronyd", ["-v"], True)
        self.command("chronyd_service", "systemctl", ["show", "chronyd.service",
                     "--property=LoadState,ActiveState,SubState,MainPID,ExecStart,FragmentPath,DropInPaths,EnvironmentFiles,UnitFileState"], True)
        self.command("kubelet_state", "systemctl", ["show", "kubelet.service", "--property=LoadState,ActiveState,SubState,UnitFileState"])
        self.command("competing_time_services", "systemctl", ["show", "systemd-timesyncd.service", "ntpd.service", "ntpsec.service", "--property=Id,LoadState,ActiveState,SubState"])
        self.command("chronyc_tracking", "chronyc", ["-n", "tracking"], True)
        self.command("chronyc_sources", "chronyc", ["-n", "sources", "-v"], True)
        self.command("chronyc_activity", "chronyc", ["-n", "activity"])
        self.command("udp_listeners", "ss", ["-H", "-lunp"], True)
        if self.result["host"] == "k8s-control01":
            for hostname, address in HOSTS.items():
                if hostname != "k8s-control01":
                    self.command("chronyc_accheck_" + hostname, "chronyc", ["-n", "accheck", address])
        self.capture(MAIN_PATH, True)
        self.capture(DROPIN_PATH)
        self.capture(STATE_DIR + "/original-ntp-pair.json")
        self.capture(STATE_DIR + "/original-ntp-dropin.json")
        self.capture("/etc/sysconfig/chronyd")
        self.capture_tree("/etc/chrony.d", suffixes=(".conf",))
        self.capture_tree("/run/chrony-dhcp", suffixes=(".sources", ".conf"))
        # chronyd -p prints configuration only; it does not start a daemon or
        # probe NTP.  Unrecognized include roots are left to manual inspection.
        allowed = True
        for root in ("/etc/chrony.d", "/run/chrony-dhcp"):
            inventory = self.result["inventories"].get(root, {})
            if inventory.get("status") not in ("PRESENT", "ABSENT") or inventory.get("truncated"):
                allowed = False
            for entry in inventory.get("entries", []):
                if entry.get("type") in ("SYMLINK_REJECTED", "SPECIAL_REJECTED") or entry.get("status"):
                    allowed = False
        for path, value in self.result["files"].items():
            if not (path == MAIN_PATH or path.startswith("/etc/chrony.d/") or path.startswith("/run/chrony-dhcp/")):
                continue
            if value.get("status") not in ("PRESENT", "ABSENT"):
                allowed = False
                continue
            raw = base64.b64decode(value.get("base64", "")).decode("utf-8", "replace")
            for line in raw.splitlines():
                words = line.split("#", 1)[0].split()
                if not words:
                    continue
                directive = words[0].lower()
                if directive == "include" and words[1:] != [DROPIN_PATH]:
                    allowed = False
                if directive == "confdir" and words[1:] != ["/etc/chrony.d"]:
                    allowed = False
                if directive == "sourcedir" and words[1:] != ["/run/chrony-dhcp"]:
                    allowed = False
        if allowed and self.result["files"][MAIN_PATH].get("status") == "PRESENT":
            self.command("chronyd_expanded_config", "chronyd", ["-p", "-f", MAIN_PATH], True, timeout=30)
        else:
            self.gap("chronyd_expanded_config", "Unsafe/incomplete configuration snapshot or include root outside fixed capture scope; parser not invoked", True)

    def kubernetes(self):
        if self.result["host"] != "k8s-control01":
            return
        # admin.conf is consumed by kubectl solely for API authentication.  Its
        # contents and Kubernetes Secret resources are never read or returned.
        resources = (
            ("calico_hostendpoints", "hostendpoints.crd.projectcalico.org"),
            ("calico_globalnetworkpolicies", "globalnetworkpolicies.crd.projectcalico.org"),
            ("calico_tiers", "tiers.crd.projectcalico.org"),
            ("calico_felixconfigurations", "felixconfigurations.crd.projectcalico.org"),
            ("kubernetes_nodes", "nodes"),
        )
        for label, resource in resources:
            self.command(label, "kubectl", ["--kubeconfig=/etc/kubernetes/admin.conf", "--request-timeout=10s", "get", resource, "-o", "json"], False, timeout=15)
        self.gap("calico_applicability", "API observations require review to determine whether host policy is enforced on these paths; unavailable API is not proof of absence", False)

    def collect(self):
        if self.result["host"] not in HOSTS:
            self.result["identity"] = {"hostname": self.hostname, "addresses": [], "valid": False, "error": "Hostname outside fixed inventory"}
            self.result["identity"].update(self.runtime_identity)
            self.gap("identity", "Hostname outside fixed inventory; no privileged observations performed", True)
            return self.finish()
        if self.runtime_identity["euid"] != 0:
            self.result["identity"] = {"hostname": self.hostname, "addresses": [], "valid": False,
                                       "error": "Expected become root for complete policy snapshots"}
            self.result["identity"].update(self.runtime_identity)
            self.gap("become_identity", "Effective uid is not root; collection not started", True)
            return self.finish()
        address_result = self.command("identity_addresses", "ip", ["-j", "address", "show"], True)
        self.result["identity"] = identity_from(self.hostname, address_result)
        self.result["identity"].update(self.runtime_identity)
        if not self.result["identity"]["valid"]:
            self.gap("identity", "Hostname/address mismatch; no privileged observations performed", True)
            return self.finish()
        self.command("ipv4_routes", "ip", ["-4", "route", "show", "table", "all"], True)
        self.command("ipv6_routes", "ip", ["-6", "route", "show", "table", "all"])
        self.command("ipv4_rules", "ip", ["-4", "rule", "show"], True)
        self.command("ipv6_rules", "ip", ["-6", "rule", "show"])
        destinations = ["10.1.93.102", "10.250.10.10"]
        if self.result["host"] == "k8s-control01":
            destinations.extend(UPSTREAMS)
            destinations.extend(address for host, address in HOSTS.items() if host != "k8s-control01")
        for target in destinations:
            self.command("route_to_" + target, "ip", ["-4", "route", "get", target], True)
        self.command("nft_ruleset", "nft", ["-n", "-a", "list", "ruleset"], True, timeout=30)
        self.command("iptables_save", "iptables-save", [], False, timeout=30)
        self.command("ip6tables_save", "ip6tables-save", [], False, timeout=30)
        self.firewalld()
        self.chrony()
        self.kubernetes()
        return self.finish()

    def finish(self):
        self.result["status"] = "COLLECTION_INCOMPLETE" if any(gap["required"] for gap in self.result["gaps"]) else "COLLECTED_REVIEW_REQUIRED"
        self.result["ended_at"] = utc_now()
        return self.result


def main():
    collector = Collector()
    try:
        result = collector.collect()
    except Exception as exc:
        collector.gap("collector", type(exc).__name__ + ": " + str(exc), True)
        result = collector.finish()
    print(json.dumps(result, ensure_ascii=True, sort_keys=True, separators=(",", ":")))
    return 0 if result["status"] == "COLLECTED_REVIEW_REQUIRED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
