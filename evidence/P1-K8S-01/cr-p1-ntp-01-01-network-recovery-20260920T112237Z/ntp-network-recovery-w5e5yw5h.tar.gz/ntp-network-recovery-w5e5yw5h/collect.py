#!/usr/bin/env python3
"""Read-only NTP network/recovery evidence; never applies policy or chrony."""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shlex
import signal
import socket
import stat
import subprocess
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True
HEAD = 'eb08dc8c4ae3505dace39e76a11ef57be75e96ce'
TREE = 'a3f0f5529dd249c9b0a48d2a8dde17997208df4d'
HOSTS = {'k8s-control01': '10.1.93.102', 'k8s-control02': '10.1.93.103',
         'k8s-control03': '10.1.93.104', 'k8s-worker01': '10.1.93.105',
         'k8s-worker02': '10.1.93.107', 'k8s-worker03': '10.1.93.108'}
UPSTREAMS = ['162.159.200.1', '162.159.200.123']
SOURCE_REF = 'https://github.com/321Team/fds-project-baseline/issues/10#issuecomment-5740306915'
KIT = Path(__file__).resolve().parent
LIMIT = 128 * 1024 * 1024


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    path.chmod(0o600)


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def read_json(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > LIMIT:
        raise ValueError('Expected a bounded regular JSON file: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        if (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
            raise ValueError('JSON changed while opening')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(LIMIT + 1)
        if len(data) > LIMIT:
            raise ValueError('JSON exceeds size limit')
        return json.loads(data.decode('utf-8'), object_pairs_hook=no_duplicates)
    finally:
        os.close(fd)


def safe_parent(path):
    path = Path(path).absolute()
    for item in [path] + list(path.parents):
        info = item.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid not in (0, os.geteuid()):
            raise ValueError('Unsafe parent type/owner: ' + str(item))
        if info.st_mode & 0o022 and not info.st_mode & stat.S_ISVTX:
            raise ValueError('Writable parent: ' + str(item))
    return path


def clean_env():
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('ANSIBLE_', 'GIT_', 'PYTHON', 'CR_NTP_'))
           and key not in ('CR_CHANGE_APPROVED', 'CR_EVIDENCE_DIR', 'SSH_ASKPASS', 'SSH_ASKPASS_REQUIRE')}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', PYTHONDONTWRITEBYTECODE='1',
               ANSIBLE_NOCOLOR='1', ANSIBLE_HOST_KEY_CHECKING='True')
    return env


def stop_group(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        return process.communicate(timeout=3)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return process.communicate()


def validate_inventory(value):
    def members(group, seen=None):
        seen = set() if seen is None else set(seen)
        if group in seen:
            raise ValueError('Cyclic inventory')
        seen.add(group)
        item = value[group]
        result = set(item.get('hosts', []))
        for child in item.get('children', []):
            result.update(members(child, seen))
        return result
    if members('k8s_nodes') != set(HOSTS):
        raise ValueError('Inventory must contain exactly the six reviewed NTP hosts')
    for host, address in HOSTS.items():
        item = value['_meta']['hostvars'][host]
        if item.get('ansible_host') != address or item.get('ansible_user') != 'svc_ansible':
            raise ValueError('Inventory identity differs: ' + host)
        if item.get('ansible_python_interpreter') != '/usr/bin/python3':
            raise ValueError('Inventory Python differs: ' + host)


def parse_host(path, host):
    result = {'transport_ok': False, 'payload_valid': False, 'collection_complete': False}
    try:
        raw = read_json(path)
        if (not isinstance(raw, dict) or raw.get('unreachable')
                or raw.get('skipped') or type(raw.get('rc')) is not int
                or not isinstance(raw.get('stdout'), str)):
            raise ValueError('Ansible command unreachable, skipped or malformed')
        result['transport_ok'] = raw['rc'] == 0 and not raw.get('failed')
        payload = json.loads(raw['stdout'], object_pairs_hook=no_duplicates)
        if (not isinstance(payload, dict) or payload.get('schema_version') != 1
                or payload.get('host') != host or payload.get('expected_address') != HOSTS[host]
                or payload.get('identity', {}).get('valid') is not True
                or not isinstance(payload.get('commands'), dict)
                or not isinstance(payload.get('files'), dict)
                or not isinstance(payload.get('gaps'), list)
                or payload.get('status') not in ('COLLECTED_REVIEW_REQUIRED', 'COLLECTION_INCOMPLETE')):
            raise ValueError('Remote evidence identity/schema mismatch')
        if not payload['commands'] or '/etc/chrony.conf' not in payload['files']:
            raise ValueError('Remote evidence is missing command/config observations')
        if any(not isinstance(gap, dict) or type(gap.get('required')) is not bool for gap in payload['gaps']):
            raise ValueError('Malformed evidence gaps')
        incomplete = any(gap.get('required') is True for gap in payload['gaps'])
        for label, entry in payload['commands'].items():
            if (not isinstance(entry, dict) or type(entry.get('required')) is not bool
                    or not isinstance(entry.get('stdout'), str) or not isinstance(entry.get('stderr'), str)
                    or type(entry.get('timed_out')) is not bool or type(entry.get('truncated')) is not bool
                    or (entry.get('rc') is not None and type(entry['rc']) is not int)):
                raise ValueError('Malformed command observation: ' + label)
            if entry['required'] and (entry.get('rc') != 0 or entry['timed_out'] or entry['truncated']):
                incomplete = True
        for filename, entry in payload['files'].items():
            if not isinstance(entry, dict) or entry.get('status') not in ('PRESENT', 'ABSENT', 'ERROR', 'UNSAFE', 'TRUNCATED'):
                raise ValueError('Malformed file observation: ' + filename)
            if entry.get('status') == 'PRESENT' and not entry.get('content_withheld'):
                content = base64.b64decode(entry.get('base64', ''), validate=True)
                if hashlib.sha256(content).hexdigest() != entry.get('sha256'):
                    raise ValueError('File content/hash mismatch: ' + filename)
            if (entry.get('required') and entry.get('status') != 'PRESENT') or entry.get('content_withheld'):
                incomplete = True
        if payload['files']['/etc/chrony.conf'].get('status') != 'PRESENT':
            incomplete = True
        result.update(payload_valid=True,
                      collection_complete=(result['transport_ok'] and not incomplete
                                           and payload['status'] == 'COLLECTED_REVIEW_REQUIRED'),
                      remote_status=payload['status'], gaps=payload['gaps'])
        return result, payload
    except (OSError, ValueError, TypeError, KeyError) as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        return result, None


class Collector:
    def __init__(self, repo, parent):
        self.repo = Path(repo).resolve()
        parent = safe_parent(parent)
        if parent == self.repo or self.repo in parent.parents:
            raise ValueError('Evidence must be outside the approved checkout')
        self.out = Path(tempfile.mkdtemp(prefix='ntp-network-recovery-', dir=parent))
        self.logs = self.out / 'controller'
        self.logs.mkdir(mode=0o700)
        self.raw = self.out / 'ansible-results'
        self.raw.mkdir(mode=0o700)
        self.hostdir = self.out / 'hosts'
        self.hostdir.mkdir(mode=0o700)
        self.env = clean_env()
        self.records = []
        self.result = {'schema_version': 1, 'started_at': now(), 'status': 'COLLECTION_INCOMPLETE',
                       'runtime_apply': 'NOT_RUN', 'runtime_acceptance': 'NOT_ASSESSED',
                       'readiness': 'REVIEW_REQUIRED', 'expected_source_sha': HEAD,
                       'expected_tree': TREE, 'hosts': {}, 'source_verified': False,
                       'collector_sha256': sha(KIT / 'collect.py'),
                       'remote_payload_sha256': sha(KIT / 'remote_readonly.py'),
                       'upstream_firewall_nat': 'NOT_OBSERVED_FROM_HOSTS',
                       'policy_change_ownership_and_recovery_order': 'MANUAL_CONFIRMATION_REQUIRED'}

    def command(self, name, argv, timeout=30, required=True):
        start = now()
        interrupted = False
        timed_out = False
        try:
            process = subprocess.Popen(argv, cwd=self.out, env=self.env, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                rc = process.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                stdout, stderr = stop_group(process)
                rc = 124
            except (KeyboardInterrupt, SystemExit):
                interrupted = True
                stdout, stderr = stop_group(process)
                rc = 130
        except OSError as error:
            rc, stdout, stderr = 127, b'', str(error).encode()
        truncated = len(stdout) > LIMIT or len(stderr) > LIMIT
        (self.logs / (name + '.stdout.log')).write_bytes(stdout[:LIMIT])
        (self.logs / (name + '.stderr.log')).write_bytes(stderr[:LIMIT])
        # The stdin payload is saved as a file; do not duplicate it in command metadata.
        display = list(argv)
        if '-a' in display:
            display[display.index('-a') + 1] = '(see REMOTE_COMMAND.json and remote_readonly.py)'
        self.records.append({'name': name, 'argv': display, 'rc': rc, 'started_at': start,
                             'ended_at': now(), 'timed_out': timed_out, 'truncated': truncated,
                             'interrupted': interrupted})
        if interrupted:
            raise KeyboardInterrupt('Collection interrupted; remote queries may finish after disconnect')
        if required and (rc or truncated):
            raise ValueError(name + ' failed; rc=' + str(rc) + '; see controller logs')
        return rc, stdout.decode('utf-8', 'replace'), stderr.decode('utf-8', 'replace')

    def verify_source(self, stage):
        self.result['source_verified'] = False
        values = {}
        for name, args in [('head', ['rev-parse', 'HEAD']), ('tree', ['rev-parse', 'HEAD^{tree}']),
                           ('status', ['status', '--porcelain', '--untracked-files=all'])]:
            values[name] = self.command('source-' + stage + '-' + name,
                                       ['git', '-C', str(self.repo)] + args)[1].strip()
        self.result.setdefault('source_checks', {})[stage] = values
        if values != {'head': HEAD, 'tree': TREE, 'status': ''}:
            raise ValueError('Approved source HEAD/tree/clean state differs')
        self.result['source_verified'] = True

    def prepare(self):
        if pwd.getpwuid(os.geteuid()).pw_name != 'server01_ansible' or socket.gethostname().split('.')[0] != 'ansible01':
            raise ValueError('Run on ansible01 as server01_ansible using the existing Ansible environment')
        self.verify_source('before')
        for executable in ['ansible', 'ansible-inventory']:
            text = self.command(executable + '-version', [executable, '--version'])[1]
            if not re.search(r'\[core 2[.]16[.]19\]', text.splitlines()[0] if text else ''):
                raise ValueError(executable + ' must use core 2.16.19')
        key = Path('/home/server01_ansible/.ssh/p1_ansible_ed25519')
        known = Path('/home/server01_ansible/.ssh/known_hosts')
        for item in (key, known):
            if not item.is_file() or not os.access(item, os.R_OK):
                raise ValueError('Existing SSH file is unavailable: ' + str(item))
        # Query the pinned inventory, then use only its verified six host identities.
        self.env['ANSIBLE_CONFIG'] = str(self.repo / 'ansible.cfg')
        _, text, _ = self.command('inventory', ['ansible-inventory', '-i', str(self.repo / 'inventory/hosts.yml'), '--list'])
        validate_inventory(json.loads(text, object_pairs_hook=no_duplicates))
        config = self.out / 'ansible-readonly.cfg'
        config.write_text('[defaults]\nhost_key_checking=True\nretry_files_enabled=False\n'
                          'forks=3\ntimeout=10\nstdout_callback=default\n'
                          '[ssh_connection]\npipelining=True\n')
        self.env['ANSIBLE_CONFIG'] = str(config)
        ssh = ' '.join(['-o BatchMode=yes', '-o PreferredAuthentications=publickey',
                        '-o PasswordAuthentication=no', '-o KbdInteractiveAuthentication=no',
                        '-o StrictHostKeyChecking=yes', '-o IdentitiesOnly=yes', '-o IdentityAgent=none',
                        '-o GlobalKnownHostsFile=/dev/null', '-o UserKnownHostsFile=' + shlex.quote(str(known)),
                        '-o ControlMaster=no', '-o ControlPath=none', '-o ControlPersist=no',
                        '-o ConnectTimeout=10', '-o ServerAliveInterval=10', '-o ServerAliveCountMax=2'])
        variables = {'ansible_user': 'svc_ansible', 'ansible_connection': 'ssh',
                     'ansible_ssh_executable': '/usr/bin/ssh', 'ansible_python_interpreter': '/usr/bin/python3',
                     'ansible_ssh_private_key_file': str(key), 'ansible_ssh_common_args': ssh,
                     'ansible_ssh_args': '-o ControlMaster=no -o ControlPersist=no',
                     'ansible_become': True, 'ansible_become_method': 'sudo',
                     'ansible_become_user': 'root', 'ansible_become_flags': '-H -S -n'}
        inventory = {'all': {'children': {'k8s_nodes': {'hosts': {h: {'ansible_host': ip} for h, ip in HOSTS.items()}}},
                             'vars': variables}}
        write_json(self.out / 'inventory.json', inventory)

    def collect(self):
        payload = (KIT / 'remote_readonly.py').read_text(encoding='utf-8')
        (self.out / 'remote_readonly.py').write_text(payload)
        (self.out / 'collect.py').write_bytes((KIT / 'collect.py').read_bytes())
        command = {'argv': ['/usr/bin/python3', '-I', '-B', '-'], 'stdin': payload, 'stdin_add_newline': False}
        write_json(self.out / 'REMOTE_COMMAND.json', {'argv': command['argv'], 'stdin_file': 'remote_readonly.py',
                                                    'stdin_add_newline': False})
        print('COLLECTING=6 hosts; read-only queries; no firewall/NTP changes', flush=True)
        rc, _, _ = self.command('ansible-readonly', ['ansible', 'k8s_nodes', '-i', str(self.out / 'inventory.json'),
                               '--become', '-m', 'ansible.builtin.command', '-a', json.dumps(command),
                               '--tree', str(self.raw)], timeout=1200, required=False)
        self.result['ansible_rc'] = rc
        for host in HOSTS:
            result, payload = parse_host(self.raw / host, host)
            self.result['hosts'][host] = result
            if payload is not None:
                write_json(self.hostdir / (host + '.json'), payload)
        self.verify_source('after')
        if rc == 0 and all(r['collection_complete'] for r in self.result['hosts'].values()):
            self.result['status'] = 'COLLECTED_REVIEW_REQUIRED'

    def package(self):
        self.result['ended_at'] = now()
        self.result['commands'] = self.records
        write_json(self.out / 'COLLECTION.json', self.result)
        template = {'reviewed_source_sha': HEAD, 'public_upstreams': UPSTREAMS,
                    'source_policy_ref': SOURCE_REF, 'network_policy_ref': '', 'recovery_ref': ''}
        write_json(self.out / 'ntp-runtime-input.unfilled.json', template)
        lines = ['# CR-P1-NTP-01-01 네트워크·복구 원문 검토', '',
                 '수집 상태: `' + self.result['status'] + '`. 배포 준비 완료·승인·운영 PASS가 아닙니다.', '',
                 '상세 원문: `hosts/<host>.json`의 commands/files 및 `ansible-results/`. 수집 실패 원문은 controller 로그에 보존합니다.', '',
                 '| 대상 | 원문 수집 | 확인 제한 |', '|---|---|---|']
        for host in HOSTS:
            entry = self.result['hosts'].get(host, {})
            state = '수집 완료·검토 필요' if entry.get('collection_complete') else '미수집/부분 수집'
            lines.append('| ' + host + ' | ' + state + ' | 원문·누락 확인 |')
        lines += ['', '## network_policy_ref에 연결할 기록', '',
                  '- control01→Cloudflare 2개 UDP destination 123 / 내부 client 5개→control01 및 반환: 원문을 보고 실제 유효 정책 판단.',
                  '- host route와 nftables만으로 상위 방화벽·SNAT·반환 허용을 확정하지 않음. 실제 장비/정책 ID·소유자·외부 source/NAT·변경 증분·반영 결과를 기존 담당이 보완.',
                  '- source 리스너·chrony allow가 아직 없어도 최초 배포 전 결함으로 단정하지 않음. 내부 실제 NTP PASS는 승인된 source 적용 후 pathcheck에서 생성.',
                  '- client 전환 전 기존 pool/DHCP 경로 유지, 전환 후 불필요 허용 제거 순서 기록.',
                  '- 실제 확인 담당 / 시각 / 기존 CR 기록 URL: 미기입.', '',
                  '## recovery_ref에 연결할 기록', '',
                  '- 각 host의 main/drop-in/기존 baseline 존재·부재, 원본 base64·SHA256·메타데이터: hosts JSON files 참조. 신규 적용 baseline이 아직 없다는 사실만으로 중단 판정하지 않음.',
                  '- 이전 네트워크 원문은 저장하되 nft/firewalld 출력을 그대로 복원용 실행문으로 사용하지 않음.',
                  '- 변경 소유자·이번 증분과 역변경·원래 승인된 pool/DHCP 경로·관리 접근·실패 host 복구 순서·성공 host/공유규칙 보존: 기존 담당 확인 필요.',
                  '- 실제 복구 기준 확인 담당 / 시각 / 기존 CR 기록 URL: 미기입.', '',
                  '## 참조 입력', '',
                  '두 실제 기록이 완성된 뒤 bind-refs 하위 명령으로 별도 runtime JSON을 생성합니다. 수집 성공만으로 빈 참조를 자동 채우지 않습니다.',
                  '발생하지 않은 정책 변경·복구 성공·NTP 응답·AC를 PASS로 기입하지 않습니다.', '']
        (self.out / 'NETWORK_RECOVERY_REVIEW.md').write_text('\n'.join(lines), encoding='utf-8')
        paths = sorted(p for p in self.out.rglob('*') if p.is_file() and not p.is_symlink())
        (self.out / 'SHA256SUMS').write_text(''.join(sha(p) + '  ' + p.relative_to(self.out).as_posix() + '\n' for p in paths))
        archive = Path(str(self.out) + '.tar.gz')
        with tarfile.open(archive, 'x:gz') as stream:
            for path in [self.out] + sorted(self.out.rglob('*')):
                if path.is_symlink() or not (path.is_file() or path.is_dir()):
                    continue
                stream.add(path, arcname=self.out.name + ('/' + path.relative_to(self.out).as_posix() if path != self.out else ''), recursive=False)
        sidecar = Path(str(archive) + '.sha256')
        with sidecar.open('x') as stream:
            stream.write(sha(archive) + '  ' + archive.name + '\n')
        print('STATUS=' + self.result['status'])
        print('RUNTIME_APPLY=NOT_RUN')
        print('EVIDENCE=' + str(archive))
        print('SHA256_SIDECAR=' + str(sidecar))
        print('REVIEW_RECORD=' + str(self.out / 'NETWORK_RECOVERY_REVIEW.md'))

    def run(self):
        try:
            self.prepare()
            self.collect()
        except (OSError, ValueError, KeyError, TypeError, KeyboardInterrupt, SystemExit) as error:
            self.result['error'] = type(error).__name__ + ': ' + str(error)
            self.result['status'] = 'COLLECTION_INCOMPLETE'
            print('STOP=' + self.result['error'], file=sys.stderr)
        self.package()
        return 0 if self.result['status'] == 'COLLECTED_REVIEW_REQUIRED' else 2


def valid_ref(text):
    value = text.strip()
    if (not value or len(value) > 2048 or re.match(r'^(PENDING|UNCONFIRMED|TODO|TBD|NOT[ _]RUN|REPLACE|CHANGE_ME)(\b|_)', value, re.I)
            or value.startswith('<') or any(ord(c) < 32 for c in value)):
        raise ValueError('Use an actual completed record reference, not an unresolved placeholder')
    return value


def bind_refs(args):
    source = Path(args.input).absolute()
    out = Path(args.output).absolute()
    safe_parent(source.parent)
    safe_parent(out.parent)
    if out == source:
        raise ValueError('Use a new output filename; original input is preserved')
    value = read_json(source)
    required = {'reviewed_source_sha', 'public_upstreams', 'source_policy_ref', 'network_policy_ref', 'recovery_ref'}
    if (not isinstance(value, dict) or set(value) != required or value['reviewed_source_sha'] != HEAD
            or value['public_upstreams'] != UPSTREAMS or value['source_policy_ref'] != SOURCE_REF):
        raise ValueError('Input must match the fixed PR29 five-field source/endpoint decision')
    if value['network_policy_ref'] or value['recovery_ref']:
        raise ValueError('Existing references must be preserved; select the unfilled input')
    value['network_policy_ref'] = valid_ref(args.network_ref)
    value['recovery_ref'] = valid_ref(args.recovery_ref)
    # This checks syntax only; the caller must first review the actual records.
    write_json(out, value)
    print('RUNTIME_INPUT=' + str(out))
    print('REFERENCE_CONTENT_VERIFICATION=NOT_AUTOMATED')
    print('RUNTIME_APPLY=NOT_RUN')
    return 0


def main(argv=None):
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    collect = commands.add_parser('collect', help='Read-only six-host observations; no apply')
    collect.add_argument('--repo', type=Path, required=True, help='Existing unpacked approved infra-ansible checkout')
    collect.add_argument('--output-parent', type=Path, default=Path.home(), help='Existing protected folder outside checkout')
    bind = commands.add_parser('bind-refs', help='After review, insert actual references into a NEW runtime input')
    bind.add_argument('--input', required=True)
    bind.add_argument('--output', required=True)
    bind.add_argument('--network-ref', required=True)
    bind.add_argument('--recovery-ref', required=True)
    commands.add_parser('plan', help='Display fixed scope without connecting or writing')
    args = parser.parse_args(argv)
    if args.action == 'plan':
        print(json.dumps({'hosts': HOSTS, 'source_sha': HEAD, 'public_upstreams': UPSTREAMS,
                          'remote_changes': 'NONE; Ansible transport/audit side effects only',
                          'network_probes': 'NONE; only local queries and optional authenticated Kubernetes GET',
                          'automatic_readiness_or_reference_approval': False}, ensure_ascii=False, indent=2))
        return 0
    try:
        if args.action == 'bind-refs':
            return bind_refs(args)
        return Collector(args.repo, args.output_parent).run()
    except (OSError, ValueError) as error:
        print('STOP=' + str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
    sys.exit(main())
