# CR-P1-NTP-01-01 네트워크·복구 원문 검토

수집 상태: `COLLECTION_INCOMPLETE`. 배포 준비 완료·승인·운영 PASS가 아닙니다.

상세 원문: `hosts/<host>.json`의 commands/files 및 `ansible-results/`. 수집 실패 원문은 controller 로그에 보존합니다.

| 대상 | 원문 수집 | 확인 제한 |
|---|---|---|
| k8s-control01 | 미수집/부분 수집 | 원문·누락 확인 |
| k8s-control02 | 미수집/부분 수집 | 원문·누락 확인 |
| k8s-control03 | 미수집/부분 수집 | 원문·누락 확인 |
| k8s-worker01 | 미수집/부분 수집 | 원문·누락 확인 |
| k8s-worker02 | 미수집/부분 수집 | 원문·누락 확인 |
| k8s-worker03 | 미수집/부분 수집 | 원문·누락 확인 |

## network_policy_ref에 연결할 기록

- control01→Cloudflare 2개 UDP destination 123 / 내부 client 5개→control01 및 반환: 원문을 보고 실제 유효 정책 판단.
- host route와 nftables만으로 상위 방화벽·SNAT·반환 허용을 확정하지 않음. 실제 장비/정책 ID·소유자·외부 source/NAT·변경 증분·반영 결과를 기존 담당이 보완.
- source 리스너·chrony allow가 아직 없어도 최초 배포 전 결함으로 단정하지 않음. 내부 실제 NTP PASS는 승인된 source 적용 후 pathcheck에서 생성.
- client 전환 전 기존 pool/DHCP 경로 유지, 전환 후 불필요 허용 제거 순서 기록.
- 실제 확인 담당 / 시각 / 기존 CR 기록 URL: 미기입.

## recovery_ref에 연결할 기록

- 각 host의 main/drop-in/기존 baseline 존재·부재, 원본 base64·SHA256·메타데이터: hosts JSON files 참조. 신규 적용 baseline이 아직 없다는 사실만으로 중단 판정하지 않음.
- 이전 네트워크 원문은 저장하되 nft/firewalld 출력을 그대로 복원용 실행문으로 사용하지 않음.
- 변경 소유자·이번 증분과 역변경·원래 승인된 pool/DHCP 경로·관리 접근·실패 host 복구 순서·성공 host/공유규칙 보존: 기존 담당 확인 필요.
- 실제 복구 기준 확인 담당 / 시각 / 기존 CR 기록 URL: 미기입.

## 참조 입력

두 실제 기록이 완성된 뒤 bind-refs 하위 명령으로 별도 runtime JSON을 생성합니다. 수집 성공만으로 빈 참조를 자동 채우지 않습니다.
발생하지 않은 정책 변경·복구 성공·NTP 응답·AC를 PASS로 기입하지 않습니다.
