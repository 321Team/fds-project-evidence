#!/bin/bash
K="kubectl --kubeconfig /etc/kubernetes/admin.conf"
while true; do echo "$(date -Is) node=$($K get node k8s-worker01 --no-headers | awk '{print $2}') boot=$($K get node k8s-worker01 -o jsonpath='{.status.nodeInfo.bootID}' | cut -c1-8) pods=$($K -n fds-app get pods --field-selector spec.nodeName=k8s-worker01 -o jsonpath='{range .items[*]}{.metadata.name}:{.status.phase}:{.status.containerStatuses[0].restartCount} {end}')"; sleep 5; done
